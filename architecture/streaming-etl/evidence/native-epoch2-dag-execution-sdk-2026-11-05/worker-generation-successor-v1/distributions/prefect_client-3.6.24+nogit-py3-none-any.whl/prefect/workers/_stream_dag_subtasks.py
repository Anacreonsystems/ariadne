"""Worker-owned DAG launches; durable fences precede every process birth."""

from __future__ import annotations

import os
import select
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from uuid import UUID

from prefect._internal.stream_dag_subtask_protocol import (
    DAG_BOOTSTRAP_MAX_BYTES,
    DAG_BOOTSTRAP_READY,
    DAG_CODE_READY,
    DAG_GO,
    DAG_PREFLIGHT_MAX_BYTES,
    DAG_RECORD_ALLOWED,
    DAG_STARTUP_TIMEOUT_SECONDS,
)
from prefect._internal.stream_route_plan import canonical_route_json
from prefect._internal.stream_subtask_entrypoint import subtask_environment
from prefect.runner._native_process import NativePidfdScope
from prefect.runner._starter_native import linux_process_identity
from prefect.streams import StreamProtocolError
from prefect.workers._stream_dag_launches import DAGLaunchJournal


class DAGSubtaskStartUnknown(StreamProtocolError):
    """A process was born but its next durable transition remains unknown."""

    def __init__(self, child: DAGSubtaskProcess) -> None:
        self.child = child
        super().__init__("DAG launch retains its exact process until verified cleanup")


@dataclass
class DAGSubtaskProcess:
    """One exact process with separate record, code, bootstrap and GO gates."""

    process: subprocess.Popen[bytes]
    home: Path
    record_fd: int
    preflight_fd: int
    ready_fd: int
    bootstrap_fd: int
    go_fd: int
    process_start_ticks: int = 0
    scope: NativePidfdScope | None = field(default=None, repr=False)
    code_ready: bool = False
    bootstrap_ready: bool = False
    released: bool = False
    bootstrap_sent_at: float | None = None

    @classmethod
    def start(
        cls,
        *,
        journal: DAGLaunchJournal,
        operation_id: UUID,
        api_url: str,
        cwd: Path,
        stream_output: bool = True,
    ) -> DAGSubtaskProcess:
        """Reserve one birth and persist its PID before any user import gate."""
        descriptors: list[int] = []
        home = Path(tempfile.mkdtemp(prefix="prefect-worker-dag-subtask-"))
        child: DAGSubtaskProcess | None = None
        try:
            record_read, record_write = os.pipe()
            preflight_read, preflight_write = os.pipe()
            ready_read, ready_write = os.pipe()
            bootstrap_read, bootstrap_write = os.pipe()
            go_read, go_write = os.pipe()
            descriptors.extend(
                (
                    record_read,
                    record_write,
                    preflight_read,
                    preflight_write,
                    ready_read,
                    ready_write,
                    bootstrap_read,
                    bootstrap_write,
                    go_read,
                    go_write,
                )
            )
            inherited = (
                record_read,
                preflight_read,
                ready_write,
                bootstrap_read,
                go_read,
            )
            with journal.spawn_stop_mutex():
                journal.reserve_birth(operation_id)
                process = subprocess.Popen(
                    [
                        sys.executable,
                        "-m",
                        "prefect._internal.stream_dag_subtask_entrypoint",
                        *(str(fd) for fd in inherited),
                    ],
                    cwd=cwd,
                    env=subtask_environment(home, api_url),
                    pass_fds=inherited,
                    stdin=subprocess.DEVNULL,
                    stdout=None if stream_output else subprocess.DEVNULL,
                    stderr=None if stream_output else subprocess.STDOUT,
                )
                # Retain ownership immediately. A PID/identity/fsync exception
                # may never erase a child or justify CLOSED_UNSTARTED.
                child = cls(
                    process,
                    home,
                    record_write,
                    preflight_write,
                    ready_read,
                    bootstrap_write,
                    go_write,
                )
                for descriptor in (
                    record_write,
                    preflight_write,
                    ready_read,
                    bootstrap_write,
                    go_write,
                ):
                    descriptors.remove(descriptor)
                for descriptor in inherited:
                    os.close(descriptor)
                    descriptors.remove(descriptor)
                child.scope = NativePidfdScope(process.pid)
                _, _, child.process_start_ticks = linux_process_identity(process.pid)
                journal.record_process(
                    operation_id, process.pid, child.process_start_ticks
                )
            return child
        except BaseException:
            if child is not None:
                # The caller retains this handle even when cleanup succeeds:
                # local durability may still be unknown and must hold capacity.
                try:
                    child.close()
                except BaseException as error:
                    raise DAGSubtaskStartUnknown(child) from error
                raise DAGSubtaskStartUnknown(child)
            shutil.rmtree(home, ignore_errors=True)
            raise
        finally:
            for descriptor in descriptors:
                os.close(descriptor)

    def _write(self, name: str, value: bytes, *, timeout: float) -> None:
        descriptor: int = getattr(self, name)
        if descriptor < 0:
            raise StreamProtocolError("DAG private message was already delivered")
        deadline = time.monotonic() + timeout
        os.set_blocking(descriptor, False)
        offset = 0
        try:
            while offset < len(value):
                remaining = max(0.0, deadline - time.monotonic())
                if not select.select([], [descriptor], [], remaining)[1]:
                    raise StreamProtocolError("DAG private message delivery timed out")
                offset += os.write(descriptor, value[offset:])
        finally:
            os.close(descriptor)
            setattr(self, name, -1)

    def allow_preflight(
        self,
        configuration: dict[str, Any],
        *,
        timeout: float = DAG_STARTUP_TIMEOUT_SECONDS,
    ) -> None:
        """Call only after exact durable RECORD returned PREFLIGHT_ALLOWED."""
        if self.code_ready:
            return
        encoded = canonical_route_json(configuration)
        if not encoded or len(encoded) > DAG_PREFLIGHT_MAX_BYTES:
            raise StreamProtocolError("DAG code preflight is oversized")
        self._write("record_fd", DAG_RECORD_ALLOWED, timeout=timeout)
        self._write("preflight_fd", encoded, timeout=timeout)
        if not select.select([self.ready_fd], [], [], timeout)[0]:
            raise StreamProtocolError("DAG code preflight readiness timed out")
        if os.read(self.ready_fd, 1) != DAG_CODE_READY:
            raise StreamProtocolError("DAG child refused its code preflight")
        self.code_ready = True

    def write_bootstrap(self, payload: dict[str, Any]) -> None:
        """Deliver an exact registered grant only to the retained code-ready child."""
        if (
            not self.code_ready
            or payload.get("child_process_id") != self.process.pid
            or payload.get("process_start_ticks") != self.process_start_ticks
        ):
            raise StreamProtocolError("DAG bootstrap has another process identity")
        encoded = canonical_route_json(payload)
        if not encoded or len(encoded) > DAG_BOOTSTRAP_MAX_BYTES:
            raise StreamProtocolError("DAG private bootstrap is oversized")
        self._write("bootstrap_fd", encoded, timeout=DAG_STARTUP_TIMEOUT_SECONDS)
        self.bootstrap_sent_at = time.monotonic()

    def observe_bootstrap_ready(self) -> bool:
        """Observe the child's signed-readiness ACK without opening the GO gate."""
        if self.bootstrap_ready:
            return True
        if self.bootstrap_sent_at is None:
            return False
        if select.select([self.ready_fd], [], [], 0)[0]:
            if os.read(self.ready_fd, 1) != DAG_BOOTSTRAP_READY:
                raise StreamProtocolError("DAG child refused its scoped bootstrap")
            self.bootstrap_ready = True
            os.close(self.ready_fd)
            self.ready_fd = -1
            return True
        if time.monotonic() - self.bootstrap_sent_at >= DAG_STARTUP_TIMEOUT_SECONDS:
            raise StreamProtocolError("DAG bootstrap acknowledgement remains unknown")
        return False

    def release(self) -> None:
        """Call only after the worker observes ACTIVE and own BOOTSTRAP_READY."""
        if self.released:
            return
        if not self.bootstrap_ready or self.bootstrap_fd >= 0:
            raise StreamProtocolError("DAG startup has no verified private bootstrap")
        self._write("go_fd", DAG_GO, timeout=DAG_STARTUP_TIMEOUT_SECONDS)
        self.released = True

    def close(self) -> None:
        """Retain every resource until exact pinned-child wait has succeeded."""
        if self.scope is not None:
            self.scope.hard_kill(self.process.pid)
        elif self.process.poll() is None:
            self.process.kill()
        self.process.wait(timeout=10)
        for name in (
            "record_fd",
            "preflight_fd",
            "ready_fd",
            "bootstrap_fd",
            "go_fd",
        ):
            descriptor: int = getattr(self, name)
            if descriptor >= 0:
                os.close(descriptor)
                setattr(self, name, -1)
        if self.scope is not None:
            self.scope.close()
        shutil.rmtree(self.home, ignore_errors=True)
