"""
Flow run command — native cyclopts implementation.

Interact with flow runs.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import tempfile
import webbrowser
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Annotated, Any, Optional, cast
from uuid import NAMESPACE_URL, UUID, uuid5

import anyio
import cyclopts
import httpx
import orjson
from rich.markup import escape
from rich.pretty import Pretty
from rich.table import Table
from starlette import status

import prefect.cli._app as _cli
from prefect._internal.control_listener import Intent
from prefect.cli._utilities import (
    exit_with_error,
    exit_with_success,
    with_cli_exception_handling,
)
from prefect.cli.flow_runs_watching import watch_flow_run
from prefect.client.orchestration import get_client
from prefect.client.orchestration._streams.client import StreamRequestError
from prefect.client.schemas.filters import FlowFilter, FlowRunFilter, LogFilter
from prefect.client.schemas.objects import StateType
from prefect.client.schemas.responses import SetStateStatus
from prefect.client.schemas.sorting import FlowRunSort, LogSort
from prefect.exceptions import Abort, FlowRunWatchError, ObjectNotFound, Pause
from prefect.logging import get_logger
from prefect.runner._control_channel import ControlSignalStatus
from prefect.runner._flow_run_executor import FlowRunExecutorContext
from prefect.runner._workspace_starter import WorkspaceResolvingEngineCommandStarter
from prefect.states import AwaitingRetry, State, exception_to_crashed_state
from prefect.types._datetime import human_friendly_diff
from prefect.utilities.asyncutils import run_sync_in_worker_thread
from prefect.utilities.engine import propose_state
from prefect.utilities.urls import url_for

if TYPE_CHECKING:
    from prefect.client.orchestration import PrefectClient
    from prefect.client.schemas.objects import FlowRun, Log


def _termination_intent() -> Intent | None:
    """Resolve the control-channel intent for this supervisor's SIGTERM behavior.

    `PREFECT_FLOW_RUN_EXECUTE_SIGTERM_BEHAVIOR` names the intent to signal, except
    for `crash`, which has none and so leaves the engine to mark the run `Crashed`.
    """
    behavior = os.environ.get("PREFECT_FLOW_RUN_EXECUTE_SIGTERM_BEHAVIOR", "").lower()
    return (
        cast("Intent", behavior) if behavior in ("reschedule", "relinquish") else None
    )


def _install_termination_handler(handler: Callable[[], None]) -> bool:
    """Install `handler` for SIGTERM on the running loop, returning whether it took.

    The handler runs as a loop callback so it can await the control channel, which a
    `signal.signal` handler cannot do.
    """
    try:
        asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, handler)
    except (NotImplementedError, RuntimeError):
        return False
    return True


async def _final_state_blocking_reschedule(
    client: PrefectClient, flow_run_id: UUID
) -> State | None:
    """Return the run's state if the server already finished it, so a SIGTERM
    reschedule must leave it alone.

    `Crashed` does not block, since an eviction observer can mark the run `Crashed`
    before the reschedule lands. A failed read does not block either.
    """
    try:
        state = (await client.read_flow_run(flow_run_id)).state
    except Exception:
        logger.warning(
            "Failed to read flow run state; rescheduling anyway.", exc_info=True
        )
        return None
    if state is not None and state.is_final() and not state.is_crashed():
        return state
    return None


flow_run_app: cyclopts.App = cyclopts.App(
    name="flow-run",
    alias="flow-runs",
    help="Interact with flow runs.",
    version_flags=[],
    help_flags=["--help"],
)

LOGS_WITH_LIMIT_FLAG_DEFAULT_NUM_LOGS = 20

logger: logging.Logger = get_logger(__name__)


async def _get_flow_run_by_id_or_name(
    client: PrefectClient,
    id_or_name: str,
) -> FlowRun:
    """Resolve a flow run identifier that could be either a UUID or a name."""
    from prefect.client.schemas.filters import FlowRunFilterName

    try:
        flow_run_id = UUID(id_or_name)
        try:
            return await client.read_flow_run(flow_run_id)
        except ObjectNotFound:
            exit_with_error(f"Flow run '{id_or_name}' not found!")
    except ValueError:
        pass

    flow_runs = await client.read_flow_runs(
        flow_run_filter=FlowRunFilter(name=FlowRunFilterName(any_=[id_or_name])),
        limit=100,
    )

    if not flow_runs:
        exit_with_error(f"Flow run '{id_or_name}' not found!")

    if len(flow_runs) == 1:
        return flow_runs[0]

    lines = [f"Multiple flow runs found with name '{id_or_name}':\n"]
    for fr in flow_runs:
        state_name = fr.state.name if fr.state else "unknown"
        timestamp = fr.start_time or fr.created
        timestamp_str = timestamp.strftime("%Y-%m-%d %H:%M:%S") if timestamp else "N/A"
        lines.append(f"  - {fr.id} ({state_name}, {timestamp_str})")

    lines.append("\nPlease retry using an explicit flow run ID.")
    exit_with_error("\n".join(lines))


@flow_run_app.command()
@with_cli_exception_handling
async def inspect(
    id: UUID,
    *,
    web: Annotated[
        bool,
        cyclopts.Parameter("--web", help="Open the flow run in a web browser."),
    ] = False,
    output: Annotated[
        Optional[str],
        cyclopts.Parameter(
            "--output",
            alias="-o",
            help="Specify an output format. Currently supports: json",
        ),
    ] = None,
):
    """View details about a flow run."""
    if output and output.lower() != "json":
        exit_with_error("Only 'json' output format is supported.")

    async with get_client() as client:
        try:
            flow_run = await client.read_flow_run(id)
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == status.HTTP_404_NOT_FOUND:
                exit_with_error(f"Flow run {id!r} not found!")
            else:
                raise

    if web:
        flow_run_url = url_for("flow-run", obj_id=id)
        if not flow_run_url:
            exit_with_error(
                "Failed to generate URL for flow run. Make sure PREFECT_UI_URL is configured."
            )

        await run_sync_in_worker_thread(webbrowser.open_new_tab, flow_run_url)
        exit_with_success(f"Opened flow run {id!r} in browser.")
    else:
        if output and output.lower() == "json":
            flow_run_json = flow_run.model_dump(mode="json")
            json_output = orjson.dumps(
                flow_run_json, option=orjson.OPT_INDENT_2
            ).decode()
            _cli.console.print(json_output, soft_wrap=True)
        else:
            _cli.console.print(Pretty(flow_run))


@flow_run_app.command()
@with_cli_exception_handling
async def ls(
    *,
    flow_name: Annotated[
        Optional[list[str]],
        cyclopts.Parameter("--flow-name", help="Name of the flow"),
    ] = None,
    limit: Annotated[
        int,
        cyclopts.Parameter("--limit", help="Maximum number of flow runs to list"),
    ] = 15,
    state: Annotated[
        Optional[list[str]],
        cyclopts.Parameter("--state", help="Name of the flow run's state"),
    ] = None,
    state_type: Annotated[
        Optional[list[str]],
        cyclopts.Parameter("--state-type", help="Type of the flow run's state"),
    ] = None,
    output: Annotated[
        Optional[str],
        cyclopts.Parameter(
            "--output",
            alias="-o",
            help="Specify an output format. Currently supports: json",
        ),
    ] = None,
):
    """View recent flow runs or flow runs for specific flows.

    Examples:
        ```bash
        $ prefect flow-runs ls --state Running
        $ prefect flow-runs ls --state Running --state late
        $ prefect flow-runs ls --state-type RUNNING
        $ prefect flow-runs ls --state-type RUNNING --state-type FAILED
        ```
    """
    if output and output.lower() != "json":
        exit_with_error("Only 'json' output format is supported.")

    prefect_state_names = {
        "SCHEDULED": "Scheduled",
        "PENDING": "Pending",
        "RUNNING": "Running",
        "COMPLETED": "Completed",
        "FAILED": "Failed",
        "CANCELLED": "Cancelled",
        "CRASHED": "Crashed",
        "PAUSED": "Paused",
        "CANCELLING": "Cancelling",
        "SUSPENDED": "Suspended",
        "AWAITINGRETRY": "AwaitingRetry",
        "RETRYING": "Retrying",
        "LATE": "Late",
    }

    state_filter = {}
    formatted_states = []

    if state:
        for s in state:
            uppercased_state = s.upper()
            if uppercased_state in prefect_state_names:
                capitalized_state = prefect_state_names[uppercased_state]
                formatted_states.append(capitalized_state)
            else:
                formatted_states.append(s)
                logger.warning(
                    f"State name {repr(s)} is not one of the official Prefect state names."
                )

        state_filter["name"] = {"any_": formatted_states}

    if state_type:
        upper_cased_states = [s.upper() for s in state_type]
        if not all(s in StateType.__members__ for s in upper_cased_states):
            exit_with_error(
                f"Invalid state type. Options are {', '.join(StateType.__members__)}."
            )

        state_filter["type"] = {
            "any_": [StateType[s].value for s in upper_cased_states]
        }

    async with get_client() as client:
        flow_runs = await client.read_flow_runs(
            flow_filter=FlowFilter(name={"any_": flow_name}) if flow_name else None,
            flow_run_filter=FlowRunFilter(state=state_filter) if state_filter else None,
            limit=limit,
            sort=FlowRunSort.EXPECTED_START_TIME_DESC,
        )
        flows_by_id = {
            flow.id: flow
            for flow in await client.read_flows(
                flow_filter=FlowFilter(id={"any_": [run.flow_id for run in flow_runs]})
            )
        }

        if not flow_runs:
            if output and output.lower() == "json":
                _cli.console.print("[]")
                return
            exit_with_success("No flow runs found.")

    if output and output.lower() == "json":
        flow_runs_json = [flow_run.model_dump(mode="json") for flow_run in flow_runs]
        json_output = orjson.dumps(flow_runs_json, option=orjson.OPT_INDENT_2).decode()
        _cli.console.print(json_output, soft_wrap=True)
    else:
        table = Table(title="Flow Runs")
        table.add_column("ID", justify="right", style="cyan", no_wrap=True)
        table.add_column("Flow", style="blue", no_wrap=True)
        table.add_column("Name", style="green", no_wrap=True)
        table.add_column("State", no_wrap=True)
        table.add_column("When", style="bold", no_wrap=True)

        for flow_run in sorted(flow_runs, key=lambda d: d.created, reverse=True):
            flow = flows_by_id[flow_run.flow_id]
            timestamp = (
                flow_run.state.state_details.scheduled_time
                if flow_run.state.is_scheduled()
                else flow_run.state.timestamp
            )
            table.add_row(
                str(flow_run.id),
                str(flow.name),
                str(flow_run.name),
                str(flow_run.state.type.value),
                human_friendly_diff(timestamp),
            )

        _cli.console.print(table)


@flow_run_app.command()
@with_cli_exception_handling
async def delete(id: UUID):
    """Delete a flow run by ID."""
    from prefect.cli._prompts import confirm

    async with get_client() as client:
        try:
            if _cli.is_interactive() and not confirm(
                f"Are you sure you want to delete flow run with id {id!r}?",
                default=False,
            ):
                exit_with_error("Deletion aborted.")
            await client.delete_flow_run(id)
        except ObjectNotFound:
            exit_with_error(f"Flow run '{id}' not found!")

    exit_with_success(f"Successfully deleted flow run '{id}'.")


@flow_run_app.command()
@with_cli_exception_handling
async def cancel(id: UUID):
    """Cancel a flow run by ID."""
    async with get_client() as client:
        cancelling_state = State(type=StateType.CANCELLING)
        try:
            flow_run = await client.read_flow_run(id)
            if (flow_run.labels or {}).get("prefect.native-streaming"):
                plan = await client.read_native_stream_deployment_plan(flow_run_id=id)
                if plan.current_launch is not None:
                    await client.cancel_native_stream(
                        flow_run_id=id,
                        operation_id=uuid5(
                            NAMESPACE_URL,
                            f"prefect-native-cli-cancel/{id}/{plan.current_launch.generation}",
                        ),
                        expected_generation=plan.current_launch.generation,
                        reason="Cancellation requested through the flow-run CLI",
                    )
                    exit_with_success(
                        f"Flow run '{id}' was successfully scheduled for cancellation."
                    )
            result = await client.set_flow_run_state(
                flow_run_id=id, state=cancelling_state
            )
        except ObjectNotFound:
            exit_with_error(f"Flow run '{id}' not found!")
        except StreamRequestError as refusal:
            exit_with_error(f"Native cancellation refused ({refusal.code}): {refusal}")

    if result.status == SetStateStatus.ABORT:
        exit_with_error(
            f"Flow run '{id}' was unable to be cancelled. Reason:"
            f" '{result.details.reason}'"
        )

    exit_with_success(f"Flow run '{id}' was successfully scheduled for cancellation.")


@flow_run_app.command()
@with_cli_exception_handling
async def retry(
    id_or_name: str,
    *,
    entrypoint: Annotated[
        Optional[str],
        cyclopts.Parameter(
            "--entrypoint",
            alias="-e",
            help=(
                "The path to a file containing the flow to run, and the name of the flow "
                "function, in the format `path/to/file.py:flow_function_name`. "
                "Required if the flow run does not have an associated deployment."
            ),
        ),
    ] = None,
):
    """Retry a failed or completed flow run.

    The flow run can be specified by either its UUID or its name. If multiple
    flow runs have the same name, you must use the UUID to disambiguate.

    If the flow run has an associated deployment, it will be scheduled for retry
    and a worker will pick it up. If there is no deployment, you must provide
    an --entrypoint to the flow code, and the flow will execute locally.

    Examples:
        ```bash
        $ prefect flow-run retry abc123-def456-7890-...
        $ prefect flow-run retry my-flow-run-name
        $ prefect flow-run retry abc123 --entrypoint ./flows/my_flow.py:my_flow
        ```
    """
    from prefect.flow_engine import run_flow
    from prefect.flows import InfrastructureBoundFlow, load_flow_from_entrypoint
    from prefect.states import Scheduled
    from prefect.utilities.callables import (
        get_call_parameters,
        parameters_to_args_kwargs,
    )

    terminal_states = {
        StateType.COMPLETED,
        StateType.FAILED,
        StateType.CANCELLED,
        StateType.CRASHED,
    }

    async with get_client() as client:
        flow_run = await _get_flow_run_by_id_or_name(client, id_or_name)
        flow_run_id = flow_run.id

        if flow_run.state is None or flow_run.state.type not in terminal_states:
            current_state = flow_run.state.type.value if flow_run.state else "unknown"
            exit_with_error(
                f"Flow run '{flow_run_id}' is in state '{current_state}' and cannot be retried. "
                f"Only flow runs in terminal states (COMPLETED, FAILED, CANCELLED, CRASHED) can be retried."
            )

        if flow_run.deployment_id:
            scheduled_state = Scheduled(message="Retried via CLI")
            try:
                result = await client.set_flow_run_state(
                    flow_run_id=flow_run_id, state=scheduled_state, force=True
                )
            except ObjectNotFound:
                exit_with_error(f"Flow run '{flow_run_id}' not found!")

            if result.status == SetStateStatus.ABORT:
                exit_with_error(
                    f"Flow run '{flow_run_id}' could not be retried. Reason: '{result.details.reason}'"
                )

            exit_with_success(
                f"Flow run '{flow_run_id}' has been scheduled for retry. "
                "A worker will pick it up shortly."
            )
        else:
            if not entrypoint:
                exit_with_error(
                    f"Flow run '{flow_run_id}' does not have an associated deployment. "
                    "Please provide an --entrypoint to the flow code.\n\n"
                    f"Example: prefect flow-run retry {flow_run_id} --entrypoint ./flows/my_flow.py:my_flow"
                )

            try:
                loaded_flow = load_flow_from_entrypoint(
                    entrypoint, use_placeholder_flow=False
                )
            except Exception as exc:
                exit_with_error(
                    f"Failed to load flow from entrypoint '{entrypoint}': {exc}"
                )

            if isinstance(loaded_flow, InfrastructureBoundFlow):
                _cli.console.print(
                    f"Retrying flow run '{flow_run_id}' on remote infrastructure "
                    f"(work pool: {loaded_flow.work_pool})..."
                )

                try:
                    await loaded_flow.retry(flow_run)
                except Exception as exc:
                    exit_with_error(f"Flow run failed: {exc}")

                flow_run = await client.read_flow_run(flow_run_id)
                final_state = flow_run.state.type.value if flow_run.state else "unknown"

                if flow_run.state and flow_run.state.is_completed():
                    exit_with_success(
                        f"Flow run '{flow_run_id}' completed successfully."
                    )
                else:
                    exit_with_error(
                        f"Flow run '{flow_run_id}' finished with state: {final_state}"
                    )
            else:
                scheduled_state = Scheduled(message="Retried via CLI (local execution)")
                try:
                    result = await client.set_flow_run_state(
                        flow_run_id=flow_run_id, state=scheduled_state, force=True
                    )
                except ObjectNotFound:
                    exit_with_error(f"Flow run '{flow_run_id}' not found!")

                if result.status == SetStateStatus.ABORT:
                    exit_with_error(
                        f"Flow run '{flow_run_id}' could not be retried. Reason: '{result.details.reason}'"
                    )

                _cli.console.print(f"Executing flow run '{flow_run_id}' locally...")

                flow_run = await client.read_flow_run(flow_run_id)

                try:
                    call_args, call_kwargs = parameters_to_args_kwargs(
                        loaded_flow.fn, flow_run.parameters if flow_run else {}
                    )
                    parameters = get_call_parameters(
                        loaded_flow.fn, call_args, call_kwargs
                    )
                except Exception as exc:
                    crashed = await exception_to_crashed_state(exc)
                    await client.set_flow_run_state(
                        flow_run_id=flow_run_id, state=crashed, force=True
                    )
                    exit_with_error(
                        "Failed to use parameters from previous attempt. Please ensure the flow signature has not changed since the last run."
                    )

                try:
                    run_flow(
                        flow=loaded_flow,
                        flow_run=flow_run,
                        return_type="state",
                        parameters=parameters,
                    )
                except Exception as exc:
                    exit_with_error(f"Flow run failed: {exc}")

                flow_run = await client.read_flow_run(flow_run_id)
                final_state = flow_run.state.type.value if flow_run.state else "unknown"

                if flow_run.state and flow_run.state.is_completed():
                    exit_with_success(
                        f"Flow run '{flow_run_id}' completed successfully."
                    )
                else:
                    exit_with_error(
                        f"Flow run '{flow_run_id}' finished with state: {final_state}"
                    )


@flow_run_app.command()
@with_cli_exception_handling
async def logs(
    id: UUID,
    *,
    head: Annotated[
        bool,
        cyclopts.Parameter(
            "--head",
            alias="-h",
            help=(
                f"Show the first {LOGS_WITH_LIMIT_FLAG_DEFAULT_NUM_LOGS} logs instead of"
                " all logs."
            ),
        ),
    ] = False,
    num_logs: Annotated[
        Optional[int],
        cyclopts.Parameter(
            "--num-logs",
            alias="-n",
            help=(
                "Number of logs to show when using the --head or --tail flag. If None,"
                f" defaults to {LOGS_WITH_LIMIT_FLAG_DEFAULT_NUM_LOGS}."
            ),
        ),
    ] = None,
    reverse: Annotated[
        bool,
        cyclopts.Parameter(
            "--reverse",
            alias="-r",
            help="Reverse the logs order to print the most recent logs first",
        ),
    ] = False,
    tail: Annotated[
        bool,
        cyclopts.Parameter(
            "--tail",
            alias="-t",
            help=(
                f"Show the last {LOGS_WITH_LIMIT_FLAG_DEFAULT_NUM_LOGS} logs instead of"
                " all logs."
            ),
        ),
    ] = False,
    output: Annotated[
        Optional[str],
        cyclopts.Parameter(
            "--output",
            alias="-o",
            help="Specify an output format. Currently supports: json",
        ),
    ] = None,
):
    """View logs for a flow run."""
    if output and output.lower() != "json":
        exit_with_error("Only 'json' output format is supported.")

    if head and tail:
        exit_with_error("Please provide either a `head` or `tail` option but not both.")

    output_json = bool(output and output.lower() == "json")
    collected_logs: list[dict[str, Any]] = []

    user_specified_num_logs = (
        num_logs or LOGS_WITH_LIMIT_FLAG_DEFAULT_NUM_LOGS
        if head or tail or num_logs
        else None
    )

    log_filter = LogFilter(flow_run_id={"any_": [id]})
    sort = LogSort.TIMESTAMP_DESC if reverse or tail else LogSort.TIMESTAMP_ASC

    def render(logs_to_render: "list[Log]") -> None:
        if output_json:
            collected_logs.extend(log.model_dump(mode="json") for log in logs_to_render)
            return
        for log in logs_to_render:
            timestamp = f"{log.timestamp:%Y-%m-%d %H:%M:%S.%f}"[:-3]
            log_level = f"{logging.getLevelName(log.level):7s}"
            flow_run_info = f"Flow run {flow_run.name!r} - {escape(log.message)}"
            _cli.console.print(
                f"{timestamp} | {log_level} | {flow_run_info}",
                soft_wrap=True,
            )

    async with get_client() as client:
        try:
            flow_run = await client.read_flow_run(id)
        except ObjectNotFound:
            exit_with_error(f"Flow run '{id!s}' not found!")

        # Bounded requests start with the requested count to avoid overfetching.
        # If that exceeds the server maximum, retry without a limit to discover
        # the server page size from the first response.
        page_size: Optional[int] = None
        offset = 0
        num_logs_collected = 0
        tail_buffer: list[Log] = []

        while True:
            if page_size is None:
                limit = user_specified_num_logs
            elif user_specified_num_logs is not None:
                remaining = user_specified_num_logs - num_logs_collected
                if remaining <= 0:
                    break
                limit = min(page_size, remaining)
            else:
                limit = page_size

            try:
                page_logs = await client.read_logs(
                    log_filter=log_filter,
                    limit=limit,
                    offset=offset,
                    sort=sort,
                )
            except httpx.HTTPStatusError as exc:
                if (
                    page_size is None
                    and limit is not None
                    and exc.response.status_code
                    == status.HTTP_422_UNPROCESSABLE_CONTENT
                    and "Invalid limit" in exc.response.text
                ):
                    limit = None
                    page_logs = await client.read_logs(
                        log_filter=log_filter,
                        limit=limit,
                        offset=offset,
                        sort=sort,
                    )
                else:
                    raise

            if page_size is None:
                page_size = limit if limit is not None else len(page_logs)
                if page_size == 0:
                    break

            if (
                user_specified_num_logs is not None
                and len(page_logs) > user_specified_num_logs - num_logs_collected
            ):
                page_logs = page_logs[: user_specified_num_logs - num_logs_collected]

            if tail:
                tail_buffer.extend(page_logs)
            else:
                render(page_logs)

            num_logs_collected += len(page_logs)
            offset += len(page_logs)

            if (
                user_specified_num_logs is not None
                and num_logs_collected >= user_specified_num_logs
            ):
                break
            if len(page_logs) < page_size:
                break

        if tail:
            # tail_buffer is in DESC order across pages; reverse to ASC unless --reverse
            if not reverse:
                tail_buffer = list(reversed(tail_buffer))
            render(tail_buffer)

    if output_json:
        json_output = orjson.dumps(collected_logs, option=orjson.OPT_INDENT_2).decode()
        _cli.console.print(json_output, soft_wrap=True)


@flow_run_app.command()
@with_cli_exception_handling
async def watch(
    id: UUID,
    *,
    timeout: Annotated[
        Optional[int],
        cyclopts.Parameter("--timeout", help="Timeout in seconds."),
    ] = None,
):
    """Watch a flow run until it reaches a terminal state."""
    async with get_client() as client:
        try:
            flow_run = await client.read_flow_run(id)
        except ObjectNotFound:
            exit_with_error(f"Flow run '{id}' not found!")

    state = flow_run.state
    if state is not None and state.is_final():
        if state.is_completed():
            exit_with_success(f"Flow run already finished in {state.name!r}.")
        exit_with_error(f"Flow run already finished in state {state.name!r}.", code=1)

    try:
        finished = await watch_flow_run(id, _cli.console, timeout=timeout)
    except FlowRunWatchError as exc:
        exit_with_error(str(exc))
    state = finished.state
    if state is None:
        exit_with_error("Flow run finished in an unknown state.")
    if state.is_completed():
        exit_with_success(f"Flow run finished successfully in {state.name!r}.")
    exit_with_error(f"Flow run finished in state {state.name!r}.", code=1)


@flow_run_app.command()
@with_cli_exception_handling
async def execute(
    id: Optional[UUID] = None,
):
    """Execute a flow run by ID."""
    if id is None:
        environ_flow_id = os.environ.get("PREFECT__FLOW_RUN_ID")
        if environ_flow_id:
            id = UUID(environ_flow_id)

    if id is None:
        exit_with_error("Could not determine the ID of the flow run to execute.")

    intent = _termination_intent()
    terminated = False
    rescheduled = False

    with tempfile.TemporaryDirectory(prefix="prefect-flow-run-") as workspace_root:
        async with FlowRunExecutorContext() as ctx:
            flow_run = await ctx.client.read_flow_run(id)

            starter = WorkspaceResolvingEngineCommandStarter(
                workspace_root=Path(workspace_root),
                control_channel=ctx.control_channel,
            )
            ctx.call_after_exit(starter.close)
            executor = ctx.create_executor(
                flow_run,
                starter,
                propose_submitting=False,
                hook_runner=starter.hook_runner,
            )

            terminating = anyio.Event()
            if intent is None or not _install_termination_handler(terminating.set):
                await executor.submit()
                return

            async with anyio.create_task_group() as tg:

                async def _terminate_on_signal() -> None:
                    nonlocal terminated, rescheduled
                    await terminating.wait()
                    logger.info("SIGTERM received, initiating graceful shutdown...")

                    # The engine must learn the intent before it sees a SIGTERM so it
                    # exits without proposing a state we then override; one that never
                    # acknowledged gets no chance to propose at all.
                    signal_status = await ctx.control_channel.signal(id, intent)
                    if signal_status is ControlSignalStatus.ALREADY_CONCLUDED:
                        logger.info(
                            "Engine already reported a final state; leaving it unchanged."
                        )
                        return

                    acknowledged = signal_status is ControlSignalStatus.ACKNOWLEDGED
                    if not acknowledged:
                        logger.warning(
                            "Engine did not acknowledge %s intent; stopping it without"
                            " a graceful signal.",
                            intent,
                        )

                    if intent == "reschedule":
                        already_final = await _final_state_blocking_reschedule(
                            ctx.client, id
                        )
                        if already_final is not None:
                            logger.info(
                                "Flow run is already in final state %r; not"
                                " rescheduling.",
                                already_final.name,
                            )
                        else:
                            try:
                                state = await propose_state(
                                    ctx.client, AwaitingRetry(), flow_run_id=id
                                )
                                rescheduled = state.is_scheduled()
                            except (Abort, Pause):
                                pass
                            except Exception:
                                logger.exception("Failed to reschedule flow run")

                    await ctx.process_manager.kill(id, force=not acknowledged)
                    terminated = True
                    # We own the run's next state now, so stop the executor before it
                    # can start a process or propose a state of its own. Do not await
                    # between the kill and this cancel, or the executor will observe
                    # the exit code and propose `Crashed` from it.
                    tg.cancel_scope.cancel()

                tg.start_soon(_terminate_on_signal)
                await executor.submit()
                # Leave a shutdown already in flight alone; it cancels the group itself.
                if not terminating.is_set():
                    tg.cancel_scope.cancel()

    # Exits go here, not inside the context: a `SystemExit` unwinding through an
    # anyio task group gets wrapped in an exception group, losing the exit code.
    if terminated:
        if intent == "reschedule":
            exit_with_success(
                "Flow run successfully rescheduled."
                if rescheduled
                else "Flow run was not rescheduled."
            )
        # Non-zero so the terminating infrastructure retries this attempt.
        exit_with_error("Flow run relinquished to infrastructure retry.")
