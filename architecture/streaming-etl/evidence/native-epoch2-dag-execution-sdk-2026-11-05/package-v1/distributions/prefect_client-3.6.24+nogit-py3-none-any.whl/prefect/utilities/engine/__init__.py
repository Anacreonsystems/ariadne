import asyncio
import contextlib
import json
import os
import signal
import threading
import time
import weakref
from collections.abc import Awaitable, Callable, Generator
from datetime import timedelta
from functools import partial
from logging import Logger
from typing import (
    TYPE_CHECKING,
    Any,
    NoReturn,
    Optional,
    TypeVar,
    Union,
    cast,
)
from uuid import UUID

import anyio
import httpx
from opentelemetry import propagate, trace
from typing_extensions import TypeIs

import prefect
import prefect.exceptions
from prefect._internal.concurrency.cancellation import get_deadline
from prefect._internal.stream_execution import (
    DAGSubtaskExecutionContext,
    get_stream_subtask_execution,
    stream_task_event_resource,
)
from prefect.client.schemas import FlowRunResult, OrchestrationResult, TaskRun
from prefect.client.schemas.objects import (
    FlowRun,
    RunType,
    TaskRunResult,
)
from prefect.client.schemas.responses import (
    SetStateStatus,
    StateAbortDetails,
    StateRejectDetails,
    StateWaitDetails,
)
from prefect.context import FlowRunContext
from prefect.events import Event, emit_event
from prefect.exceptions import (
    Pause,
    PrefectException,
    TerminationSignal,
    UpstreamTaskError,
)
from prefect.flows import Flow
from prefect.futures import PrefectFuture
from prefect.logging.loggers import get_logger
from prefect.results import ResultRecord, should_persist_result
from prefect.settings import PREFECT_LOGGING_LOG_PRINTS
from prefect.states import State
from prefect.streams import (
    RunningStreamGraph,
    SealedStreamGraph,
    Stream,
    StreamCollection,
    StreamGraph,
    StreamOperatorHandle,
    StreamOutput,
    StreamProtocolError,
)
from prefect.utilities.asyncutils import run_coro_as_sync
from prefect.tasks import Task
from prefect.utilities.annotations import allow_failure, opaque, quote
from prefect.utilities.collections import StopVisiting, visit_collection
from prefect.utilities.text import truncated_to

if TYPE_CHECKING:
    from prefect.client.orchestration import PrefectClient, SyncPrefectClient

API_HEALTHCHECKS: dict[str, float] = {}
UNTRACKABLE_TYPES: set[type[Any]] = {bool, type(None), type(...), type(NotImplemented)}
_RUN_SCHEMA_TYPES: tuple[type[Any], ...] = (FlowRun, TaskRun)
engine_logger: Logger = get_logger("engine")

_STREAM_GRAPH_METADATA_TYPES: tuple[type[Any], ...] = (
    StreamGraph,
    StreamOperatorHandle,
    StreamOutput,
    SealedStreamGraph,
    RunningStreamGraph,
)


def refuse_stream_graph_dependencies(value: Any) -> None:
    """Reject declaration metadata without collecting or starting its graph.

    Known containers are traversed explicitly, including annotation tuples.
    Arbitrary object attributes are not inspected and container cycles are safe.
    """
    pending: list[Any] = [value]
    visited: set[int] = set()
    while pending:
        item = pending.pop()
        if isinstance(item, _STREAM_GRAPH_METADATA_TYPES):
            raise StreamProtocolError(
                "StreamGraph metadata is not an executable finite Task dependency"
            )
        if isinstance(item, (list, tuple, dict, set, frozenset)):
            container = cast(
                list[Any]
                | tuple[Any, ...]
                | dict[Any, Any]
                | set[Any]
                | frozenset[Any],
                item,
            )
            identity = id(container)
            if identity in visited:
                continue
            visited.add(identity)
            if isinstance(container, dict):
                pending.extend(container.keys())
                pending.extend(container.values())
            else:
                pending.extend(container)


def _raise_on_run_schema_unless_opaque(obj: Any, context: dict[str, Any]) -> None:
    """Raise a clear error when a Prefect run schema object is passed as a
    task argument without the `opaque` annotation.

    These Pydantic models contain a `.state` attribute that
    `visit_collection` would recurse into, causing the embedded state
    to be mistakenly treated as an upstream task dependency.
    """
    if isinstance(obj, _RUN_SCHEMA_TYPES) and not isinstance(
        context.get("annotation"), opaque
    ):
        type_name = type(obj).__name__
        lower = type_name[0].lower() + type_name[1:]
        raise PrefectException(
            f"Passing a `{type_name}` object as a task argument is not supported."
            " Prefect inspects task arguments for upstream `State` and"
            " `PrefectFuture` dependencies, which causes the embedded"
            f" `{type_name}.state` attribute to be mistakenly treated as an"
            " upstream task dependency. Pass individual fields instead"
            f" (e.g. `{lower}.id`) or wrap the object with"
            f" `opaque({lower})` to skip dependency traversal."
        )


T = TypeVar("T")
_prefect_sigterm_handler_depth = 0
_prefect_sigterm_bridge_lock = threading.RLock()


def _prefect_sigterm_handler(sig_num: int, *args: object) -> NoReturn:
    raise TerminationSignal(signal=sig_num)


def is_prefect_sigterm_handler_installed() -> bool:
    """Return whether Prefect's SIGTERM bridge is currently installed."""
    with _prefect_sigterm_bridge_lock:
        try:
            return signal.getsignal(signal.SIGTERM) is _prefect_sigterm_handler
        except ValueError:
            # Signals only work in the main thread; treat this as not installed.
            return False


def can_ack_control_intent() -> bool:
    """Return whether the child can safely acknowledge a queued control intent.

    The check is protected by the same lock used when `capture_sigterm()`
    installs and restores Prefect's SIGTERM bridge. On POSIX, the runner's
    subsequent real `SIGTERM` is the actual cancellation trigger, so the
    child only needs to verify that Prefect still owns the live bridge before
    advertising readiness with `b"a"`.
    """
    with _prefect_sigterm_bridge_lock:
        try:
            return signal.getsignal(signal.SIGTERM) is _prefect_sigterm_handler
        except ValueError:
            return False


def commit_control_intent_and_ack(
    commit_intent: Callable[[], None],
    clear_intent: Callable[[], None],
    send_ack: Callable[[], None],
    trigger_cancel: Callable[[], None] | None = None,
) -> bool:
    """Atomically commit control intent and acknowledge it to the runner.

    The SIGTERM bridge check, intent commit, and ack write must share the same
    lock used by `capture_sigterm()` to install and restore Prefect's SIGTERM
    handler. Otherwise, teardown can restore the original handler after the
    child decides it is safe to ack but before the runner observes `b"a"`.
    """

    with _prefect_sigterm_bridge_lock:
        try:
            if signal.getsignal(signal.SIGTERM) is not _prefect_sigterm_handler:
                return False
        except ValueError:
            return False

        commit_intent()
        try:
            send_ack()
        except OSError:
            clear_intent()
            return False

        if trigger_cancel is not None:
            try:
                trigger_cancel()
            except (OSError, ValueError, RuntimeError):
                # At this point the runner has already observed the ack.
                # Preserve the committed intent and let the caller continue.
                pass

        return True


async def collect_task_run_inputs(
    expr: Any, max_depth: int = -1
) -> set[Union[TaskRunResult, FlowRunResult]]:
    """
    This function recurses through an expression to generate a set of any discernible
    task run inputs it finds in the data structure. It produces a set of all inputs
    found.

    Examples:

        ```python
        task_inputs = {
            k: await collect_task_run_inputs(v) for k, v in parameters.items()
         }
        ```
    """
    # TODO: This function needs to be updated to detect parameters and constants

    inputs: set[Union[TaskRunResult, FlowRunResult]] = set()

    def add_futures_and_states_to_inputs(obj: Any) -> None:
        if isinstance(obj, (Stream, StreamCollection)):
            stream = obj.stream if isinstance(obj, StreamCollection) else obj
            if stream.producer_task_run_id is not None:
                inputs.add(TaskRunResult(id=stream.producer_task_run_id))
        elif isinstance(obj, PrefectFuture):
            inputs.add(TaskRunResult(id=obj.task_run_id))
        elif isinstance(obj, State):
            if obj.state_details.task_run_id:
                inputs.add(
                    TaskRunResult(
                        id=obj.state_details.task_run_id,
                    )
                )
        # Expressions inside quotes should not be traversed
        elif isinstance(obj, quote):
            raise StopVisiting
        else:
            res = get_state_for_result(obj)
            if res:
                state, run_type = res
                run_result = state.state_details.to_run_result(run_type)
                if run_result:
                    inputs.add(run_result)

    visit_collection(
        expr,
        visit_fn=add_futures_and_states_to_inputs,
        return_data=False,
        max_depth=max_depth,
    )

    return inputs


def collect_task_run_inputs_sync(
    expr: Any, future_cls: Any = PrefectFuture, max_depth: int = -1
) -> set[Union[TaskRunResult, FlowRunResult]]:
    """
    This function recurses through an expression to generate a set of any discernible
    task run inputs it finds in the data structure. It produces a set of all inputs
    found.

    Examples:
        ```python
        task_inputs = {
            k: collect_task_run_inputs_sync(v) for k, v in parameters.items()
         }
        ```
    """
    # TODO: This function needs to be updated to detect parameters and constants

    inputs: set[Union[TaskRunResult, FlowRunResult]] = set()

    def add_futures_and_states_to_inputs(obj: Any) -> None:
        if isinstance(obj, (Stream, StreamCollection)):
            stream = obj.stream if isinstance(obj, StreamCollection) else obj
            if stream.producer_task_run_id is not None:
                inputs.add(TaskRunResult(id=stream.producer_task_run_id))
        elif isinstance(obj, future_cls) and hasattr(obj, "task_run_id"):
            inputs.add(
                TaskRunResult(
                    id=obj.task_run_id,
                )
            )
        elif isinstance(obj, State):
            if obj.state_details.task_run_id:
                inputs.add(
                    TaskRunResult(
                        id=obj.state_details.task_run_id,
                    )
                )
        # Expressions inside quotes should not be traversed
        elif isinstance(obj, quote):
            raise StopVisiting
        else:
            res = get_state_for_result(obj)
            if res:
                state, run_type = res
                run_result = state.state_details.to_run_result(run_type)
                if run_result:
                    inputs.add(run_result)

    visit_collection(
        expr,
        visit_fn=add_futures_and_states_to_inputs,
        return_data=False,
        max_depth=max_depth,
    )

    return inputs


@contextlib.contextmanager
def capture_sigterm() -> Generator[None, Any, None]:
    """Install a SIGTERM handler that raises `TerminationSignal`.

    Only the outermost Prefect flow engine in a process installs the handler
    by default. Nested subflow engines reuse that existing Prefect-owned
    handler when it is still active; if user or library code temporarily
    replaced `SIGTERM`, the nested scope reinstalls Prefect's bridge for the
    duration of that scope. This guard is based on explicit local ownership
    state plus the currently installed handler, not on `FlowRunContext`: a
    fresh subprocess may hydrate a parent flow context before its own engine
    starts, and still needs to install a SIGTERM bridge for the child process.

    The handler does not need to interpret intent. The engine's
    `except TerminationSignal` block consults
    `prefect._internal.control_listener.get_intent()` directly when
    dispatching (today: `handle_cancellation` vs `handle_crash`; in a
    future PR: plus `handle_suspension`).

    The runner control listener only connects while this context is active.
    Cancels that land before the bridge is armed fall back to the runner's
    existing crash-style termination path; once this context is active, the
    child can acknowledge control intent and treat the later SIGTERM as an
    intentional cancellation.
    """
    from prefect._internal import control_listener

    global _prefect_sigterm_handler_depth

    original_term_handler = None
    handler_installed = False
    reusing_prefect_handler = False
    current_term_handler: object | None = None
    should_start_control_listener = False

    with _prefect_sigterm_bridge_lock:
        try:
            current_term_handler = signal.getsignal(signal.SIGTERM)
        except ValueError:
            # Signals only work in the main thread
            current_term_handler = None

        if (
            _prefect_sigterm_handler_depth > 0
            and current_term_handler is _prefect_sigterm_handler
        ):
            _prefect_sigterm_handler_depth += 1
            reusing_prefect_handler = True
            should_start_control_listener = _prefect_sigterm_handler_depth == 1
        else:
            try:
                original_term_handler = signal.signal(
                    signal.SIGTERM, _prefect_sigterm_handler
                )
                handler_installed = True
                _prefect_sigterm_handler_depth += 1
                should_start_control_listener = _prefect_sigterm_handler_depth == 1
            except ValueError:
                # Signals only work in the main thread
                pass

    try:
        if should_start_control_listener:
            control_listener.start()
        yield
    except TerminationSignal as exc:
        # Termination signals are swapped out during a flow run to perform
        # a graceful shutdown and raise this exception. This `os.kill` call
        # ensures that the previous handler, likely the Python default,
        # gets called as well — but only when the signal was actually
        # delivered as a raw external termination, not when the control
        # channel has already marked it as an intentional runner-driven
        # teardown (including the Windows `_thread.interrupt_main` path).
        # Any non-None intent means "control listener is driving this
        # teardown, stay out of the way" — not just cancel. Suspension
        # will land here the same way a cancel does today.
        if original_term_handler is not None and control_listener.get_intent() is None:
            with _prefect_sigterm_bridge_lock:
                signal.signal(exc.signal, original_term_handler)
            os.kill(os.getpid(), exc.signal)

        raise

    finally:
        current_depth = _prefect_sigterm_handler_depth
        keep_prefect_handler_installed = False
        if reusing_prefect_handler:
            with _prefect_sigterm_bridge_lock:
                _prefect_sigterm_handler_depth -= 1
                current_depth = _prefect_sigterm_handler_depth
        elif handler_installed:
            with _prefect_sigterm_bridge_lock:
                _prefect_sigterm_handler_depth -= 1
                # On POSIX, once a runner-delivered control intent is active
                # the process is in terminal teardown. Keep Prefect's SIGTERM
                # bridge installed instead of restoring the original handler,
                # so a late runner SIGTERM cannot land on SIG_DFL or user code
                # after we've already accepted the control intent.
                keep_prefect_handler_installed = (
                    os.name != "nt" and control_listener.get_intent() is not None
                )
                if (
                    not keep_prefect_handler_installed
                    and original_term_handler is not None
                ):
                    signal.signal(signal.SIGTERM, original_term_handler)
                current_depth = _prefect_sigterm_handler_depth

        if current_depth == 0:
            control_listener.stop()


async def resolve_inputs(
    parameters: dict[str, Any], return_data: bool = True, max_depth: int = -1
) -> dict[str, Any]:
    """
    Resolve any `Quote`, `PrefectFuture`, or `State` types nested in parameters into
    data.

    Returns:
        A copy of the parameters with resolved data

    Raises:
        UpstreamTaskError: If any of the upstream states are not `COMPLETED`
    """

    futures: set[PrefectFuture[Any]] = set()
    states: set[State[Any]] = set()
    result_by_state: dict[State[Any], Any] = {}

    if not parameters:
        return {}

    def collect_futures_and_states(expr: Any, context: dict[str, Any]) -> Any:
        # Expressions inside quotes should not be traversed
        if isinstance(context.get("annotation"), quote):
            raise StopVisiting()

        _raise_on_run_schema_unless_opaque(expr, context)

        if isinstance(expr, PrefectFuture):
            fut: PrefectFuture[Any] = expr
            futures.add(fut)
        if isinstance(expr, State):
            state: State[Any] = expr
            states.add(state)

        return cast(Any, expr)

    visit_collection(
        parameters,
        visit_fn=collect_futures_and_states,
        return_data=False,
        max_depth=max_depth,
        context={},
    )

    # Only retrieve the result if requested as it may be expensive
    if return_data:
        finished_states = [state for state in states if state.is_final()]

        state_results = [
            state.aresult(raise_on_failure=False) for state in finished_states
        ]
        state_results = await asyncio.gather(*state_results)

        for state, result in zip(finished_states, state_results):
            result_by_state[state] = result

    def resolve_input(expr: Any, context: dict[str, Any]) -> Any:
        state: Optional[State[Any]] = None

        # Expressions inside quotes should not be modified
        if isinstance(context.get("annotation"), quote):
            raise StopVisiting()

        _raise_on_run_schema_unless_opaque(expr, context)

        if isinstance(expr, PrefectFuture):
            state = expr.state
        elif isinstance(expr, State):
            state = expr
        else:
            return expr

        # Do not allow uncompleted upstreams unless `allow_failure` has been used
        # for failed or failure-derived (PENDING/NotReady) states
        if not state.is_completed() and not (
            # TODO: Note that the contextual annotation here is only at the current level
            #       if `allow_failure` is used then another annotation is used, this will
            #       incorrectly evaluate to false — to resolve this, we must track all
            #       annotations wrapping the current expression but this is not yet
            #       implemented.
            isinstance(context.get("annotation"), allow_failure)
            and (state.is_failed() or (state.is_pending() and state.name == "NotReady"))
        ):
            raise UpstreamTaskError(
                f"Upstream task run '{state.state_details.task_run_id}' did not reach a"
                " 'COMPLETED' state."
            )

        # When allow_failure is used and the state is not final (e.g. PENDING/NotReady
        # from a cascading upstream failure), return state.data directly since
        # result_by_state is only populated for final states.
        if not state.is_final() and isinstance(
            context.get("annotation"), allow_failure
        ):
            return state.data

        resolved = result_by_state.get(state)
        _raise_on_run_schema_unless_opaque(resolved, context)
        return resolved

    resolved_parameters: dict[str, Any] = {}
    for parameter, value in parameters.items():
        try:
            resolved_parameters[parameter] = visit_collection(
                value,
                visit_fn=resolve_input,
                return_data=return_data,
                # we're manually going 1 layer deeper here
                max_depth=max_depth - 1,
                remove_annotations=True,
                context={},
            )
        except (UpstreamTaskError, PrefectException):
            raise
        except Exception as exc:
            raise PrefectException(
                f"Failed to resolve inputs in parameter {parameter!r}. If your"
                " parameter type is not supported, consider using the `quote`"
                " annotation to skip resolution of inputs, or the `opaque`"
                " annotation to resolve the value without traversing its contents."
            ) from exc

    return resolved_parameters


def _is_result_record(data: Any) -> TypeIs[ResultRecord[Any]]:
    return isinstance(data, ResultRecord)


async def propose_state(
    client: "PrefectClient",
    state: State[Any],
    flow_run_id: UUID,
    force: bool = False,
) -> State[Any]:
    """
    Propose a new state for a flow run, invoking Prefect orchestration logic.

    If the proposed state is accepted, the provided `state` will be augmented with
     details and returned.

    If the proposed state is rejected, a new state returned by the Prefect API will be
    returned.

    If the proposed state results in a WAIT instruction from the Prefect API, the
    function will sleep and attempt to propose the state again.

    If the proposed state results in an ABORT instruction from the Prefect API, an
    error will be raised.

    Args:
        state: a new state for a flow run
        flow_run_id: an optional flow run id, used when proposing flow run states

    Returns:
        a State model representation of the flow run state

    Raises:
        prefect.exceptions.Abort: if an ABORT instruction is received from
            the Prefect API
    """

    if not flow_run_id:
        raise ValueError("You must provide a `flow_run_id`")

    # Handle sub-flow tracing
    if state.is_final():
        result: Any
        if _is_result_record(state.data):
            result = state.data.result
        else:
            result = state.data

        link_state_to_flow_run_result(state, result)

    # Handle repeated WAITs in a loop instead of recursively, to avoid
    # reaching max recursion depth in extreme cases.
    async def set_state_and_handle_waits(
        set_state_func: Callable[[], Awaitable[OrchestrationResult[Any]]],
    ) -> OrchestrationResult[Any]:
        response = await set_state_func()
        while response.status == SetStateStatus.WAIT:
            if TYPE_CHECKING:
                assert isinstance(response.details, StateWaitDetails)
            engine_logger.debug(
                f"Received wait instruction for {response.details.delay_seconds}s: "
                f"{response.details.reason}"
            )
            await anyio.sleep(response.details.delay_seconds)
            response = await set_state_func()
        return response

    set_state = partial(client.set_flow_run_state, flow_run_id, state, force=force)
    response = await set_state_and_handle_waits(set_state)

    # Parse the response to return the new state
    if response.status == SetStateStatus.ACCEPT:
        # Update the state with the details if provided
        if TYPE_CHECKING:
            assert response.state is not None
        state.id = response.state.id
        state.timestamp = response.state.timestamp
        if response.state.state_details:
            state.state_details = response.state.state_details
        return state

    elif response.status == SetStateStatus.ABORT:
        if TYPE_CHECKING:
            assert isinstance(response.details, StateAbortDetails)

        raise prefect.exceptions.Abort(response.details.reason)

    elif response.status == SetStateStatus.REJECT:
        if TYPE_CHECKING:
            assert response.state is not None
            assert isinstance(response.details, StateRejectDetails)

        if response.state.is_paused():
            raise Pause(response.details.reason, state=response.state)
        return response.state

    else:
        raise ValueError(
            f"Received unexpected `SetStateStatus` from server: {response.status!r}"
        )


def propose_state_sync(
    client: "SyncPrefectClient",
    state: State[Any],
    flow_run_id: UUID,
    force: bool = False,
) -> State[Any]:
    """
    Propose a new state for a flow run, invoking Prefect orchestration logic.

    If the proposed state is accepted, the provided `state` will be augmented with
     details and returned.

    If the proposed state is rejected, a new state returned by the Prefect API will be
    returned.

    If the proposed state results in a WAIT instruction from the Prefect API, the
    function will sleep and attempt to propose the state again.

    If the proposed state results in an ABORT instruction from the Prefect API, an
    error will be raised.

    Args:
        state: a new state for the flow run
        flow_run_id: an optional flow run id, used when proposing flow run states

    Returns:
        a State model representation of the flow run state

    Raises:
        ValueError: if flow_run_id is not provided
        prefect.exceptions.Abort: if an ABORT instruction is received from
            the Prefect API
    """

    # Handle sub-flow tracing
    if state.is_final():
        if _is_result_record(state.data):
            result = state.data.result
        else:
            result = state.data

        link_state_to_flow_run_result(state, result)

    # Handle repeated WAITs in a loop instead of recursively, to avoid
    # reaching max recursion depth in extreme cases.
    def set_state_and_handle_waits(
        set_state_func: Callable[[], OrchestrationResult[Any]],
    ) -> OrchestrationResult[Any]:
        response = set_state_func()
        while response.status == SetStateStatus.WAIT:
            if TYPE_CHECKING:
                assert isinstance(response.details, StateWaitDetails)
            engine_logger.debug(
                f"Received wait instruction for {response.details.delay_seconds}s: "
                f"{response.details.reason}"
            )
            time.sleep(response.details.delay_seconds)
            response = set_state_func()
        return response

    # Attempt to set the state
    set_state = partial(client.set_flow_run_state, flow_run_id, state, force=force)
    response = set_state_and_handle_waits(set_state)

    # Parse the response to return the new state
    if response.status == SetStateStatus.ACCEPT:
        if TYPE_CHECKING:
            assert response.state is not None
        # Update the state with the details if provided
        state.id = response.state.id
        state.timestamp = response.state.timestamp
        if response.state.state_details:
            state.state_details = response.state.state_details
        return state

    elif response.status == SetStateStatus.ABORT:
        if TYPE_CHECKING:
            assert isinstance(response.details, StateAbortDetails)
        raise prefect.exceptions.Abort(response.details.reason)

    elif response.status == SetStateStatus.REJECT:
        if TYPE_CHECKING:
            assert response.state is not None
            assert isinstance(response.details, StateRejectDetails)
        if response.state.is_paused():
            raise Pause(response.details.reason, state=response.state)
        return response.state

    else:
        raise ValueError(
            f"Received unexpected `SetStateStatus` from server: {response.status!r}"
        )


def get_state_for_result(obj: Any) -> Optional[tuple[State, RunType]]:
    """
    Get the state related to a result object.

    `link_state_to_result` must have been called first.

    For objects that support `__weakref__`, the entry stored by
    `link_state_to_result` carries a weak reference back to the original
    object. We verify here that the entry's weak reference still points
    to the *same* object that registered the entry — not just to *some*
    object that happens to share its `id()`. This prevents stale hits
    caused by CPython recycling a freed memory address. Stale entries
    are evicted on detection.

    For objects that do not support `__weakref__` (plain `dict`, `list`,
    `set`, `str`, `int`, `tuple`, ...), the entry has no weak reference
    and we fall back to the legacy `id()`-only lookup. This preserves
    today's behavior for those types — including the latent stale-id
    bug — and isolates the limitation to a single named code path.
    """
    # See https://github.com/PrefectHQ/prefect/issues/20558 for background
    # on the stale-id bug and the broader product discussion around
    # non-weakref-able types.
    flow_run_context = FlowRunContext.get()
    if flow_run_context is None:
        return None

    entry = flow_run_context.run_results.get(id(obj))
    if entry is None:
        return None

    state, run_type, ref = entry
    if ref is not None and ref() is not obj:
        # Stale: the original object that registered this entry is
        # either gone (ref() is None) or this `obj` is a different
        # object that happens to share the recycled `id()`. Evict and
        # miss.
        flow_run_context.run_results.pop(id(obj), None)
        return None

    return state, run_type


def link_state_to_flow_run_result(state: State, result: Any) -> None:
    """Creates a link between a state and flow run result"""
    link_state_to_result(state, result, RunType.FLOW_RUN)


def link_state_to_task_run_result(state: State, result: Any) -> None:
    """Creates a link between a state and task run result"""
    link_state_to_result(state, result, RunType.TASK_RUN)


def link_state_to_result(state: State, result: Any, run_type: RunType) -> None:
    """
    Caches a link between a state and a result and its components using
    the `id` of the components to map to the state. The cache is persisted to the
    current flow run context since task relationships are limited to within a flow run.

    This allows dependency tracking to occur when results are passed around.
    Note: Because `id` is used, we cannot cache links between singleton objects.

    We only cache the relationship between components 1-layer deep.
    Example:
        Given the result [1, ["a","b"], ("c",)], the following elements will be
        mapped to the state:
        - [1, ["a","b"], ("c",)]
        - ["a","b"]
        - ("c",)

        Note: the int `1` will not be mapped to the state because it is a singleton.

    Identity tracking:
        For objects that support `__weakref__` (most user-defined classes,
        pydantic models, dataclasses), each entry stores a weak reference
        back to the original object. `get_state_for_result` verifies that
        the weak reference still points to the *same* object before
        returning a hit, so a recycled memory address can never silently
        inherit a previous task's state.

        For objects that do not support `__weakref__` (plain `dict`,
        `list`, `set`, `str`, `int`, `tuple`, ...), the entry has no weak
        reference and the legacy `id()`-only lookup is used. The known
        stale-id limitation is preserved for those types and isolated to
        a single named code path.

    Other Notes:
    We do not hash the result because:
    - If changes are made to the object in the flow between task calls, we can still
      track that they are related.
    - Hashing can be expensive.
    - Not all objects are hashable.
    - Hash-based keying would also conflate equal-but-distinct objects
      from unrelated tasks.

    We do not set an attribute, e.g. `__prefect_state__`, on the result because:

    - Mutating user's objects is dangerous.
    - Unrelated equality comparisons can break unexpectedly.
    - The field can be preserved on copy.
    - We cannot set this attribute on Python built-ins.
    """
    flow_run_context = FlowRunContext.get()
    # Drop the data field to avoid holding a strong reference to the result
    # Holding large user objects in memory can cause memory bloat
    linked_state = state.model_copy(update={"data": None})

    if flow_run_context:

        def link_if_trackable(obj: Any) -> None:
            """Track connection between a task run result and its associated state if it has a unique ID.

            We cannot track booleans, Ellipsis, None, NotImplemented, or the integers from -5 to 256
            because they are singletons.

            This function will mutate the State if the object is an untrackable type by setting the value
            for `State.state_details.untrackable_result` to `True`.

            """
            if (type(obj) in UNTRACKABLE_TYPES) or (
                isinstance(obj, int) and (-5 <= obj <= 256)
            ):
                state.state_details.untrackable_result = True
                return

            # Attach a weak reference for identity verification on
            # lookup. `type(obj).__weakrefoffset__` is the canonical
            # CPython check for whether instances of a type support
            # `__weakref__` — it's non-zero for user classes / pydantic
            # models / dataclasses and zero for builtins like `dict`,
            # `list`, `str`, `int`, `tuple`, `set`. Using the offset
            # avoids the cost of catching `TypeError` from a doomed
            # `weakref.ref(obj)` call on every non-weakref-able result.
            if type(obj).__weakrefoffset__:
                ref = weakref.ref(obj)
            else:
                ref = None

            flow_run_context.run_results[id(obj)] = (linked_state, run_type, ref)

        visit_collection(expr=result, visit_fn=link_if_trackable, max_depth=1)


def should_log_prints(flow_or_task: Union["Flow[..., Any]", "Task[..., Any]"]) -> bool:
    flow_run_context = FlowRunContext.get()

    if flow_or_task.log_prints is None:
        if flow_run_context:
            return flow_run_context.log_prints
        else:
            return PREFECT_LOGGING_LOG_PRINTS.value()

    return flow_or_task.log_prints


async def check_api_reachable(client: "PrefectClient", fail_message: str) -> None:
    # Do not perform a healthcheck if it exists and is not expired
    api_url = str(client.api_url)
    if api_url in API_HEALTHCHECKS:
        expires = API_HEALTHCHECKS[api_url]
        if expires > time.monotonic():
            return

    connect_error = await client.api_healthcheck()
    if connect_error:
        raise RuntimeError(
            f"{fail_message}. Failed to reach API at {api_url}."
        ) from connect_error

    # Create a 10 minute cache for the healthy response
    API_HEALTHCHECKS[api_url] = get_deadline(60 * 10)


def build_task_run_state_change_event(
    task_run: TaskRun,
    initial_state: Optional[State[Any]],
    validated_state: State[Any],
    follows: Optional[Event] = None,
) -> Event:
    """Build the ordinary signed TaskRun event without choosing a transport."""
    state_message_truncation_length = 100_000

    if _is_result_record(validated_state.data) and should_persist_result():
        data = validated_state.data.metadata.model_dump(mode="json")
    else:
        data = None

    payload = {
        "intended": {
            "from": str(initial_state.type.value) if initial_state else None,
            "to": str(validated_state.type.value) if validated_state else None,
        },
        "initial_state": (
            {
                "type": str(initial_state.type.value),
                "name": initial_state.name,
                "message": truncated_to(
                    state_message_truncation_length, initial_state.message
                ),
                "state_details": initial_state.state_details.model_dump(
                    mode="json",
                    exclude_none=True,
                    exclude_unset=True,
                    exclude={"flow_run_id", "task_run_id"},
                ),
            }
            if initial_state
            else None
        ),
        "validated_state": {
            "type": str(validated_state.type.value),
            "name": validated_state.name,
            "message": truncated_to(
                state_message_truncation_length, validated_state.message
            ),
            "state_details": validated_state.state_details.model_dump(
                mode="json",
                exclude_none=True,
                exclude_unset=True,
                exclude={"flow_run_id", "task_run_id"},
            ),
            "data": data,
        },
        "task_run": task_run.model_dump(
            mode="json",
            exclude_none=True,
            exclude={
                "id",
                "created",
                "updated",
                "flow_run_id",
                "state_id",
                "state_type",
                "state_name",
                "state",
                # server materialized fields
                "estimated_start_time_delta",
                "estimated_run_time",
            },
        ),
    }
    resource = {
        "prefect.resource.id": f"prefect.task-run.{task_run.id}",
        "prefect.resource.name": task_run.name,
        "prefect.run-count": str(task_run.run_count),
        "prefect.state-message": truncated_to(
            state_message_truncation_length, validated_state.message
        ),
        "prefect.state-name": validated_state.name or "",
        "prefect.state-timestamp": (
            validated_state.timestamp.isoformat()
            if validated_state and validated_state.timestamp
            else ""
        ),
        "prefect.state-type": str(validated_state.type.value),
        "prefect.orchestration": "client",
    }
    resource = stream_task_event_resource(task_run, validated_state, payload, resource)
    related = [
        {"prefect.resource.id": f"prefect.tag.{tag}", "prefect.resource.role": "tag"}
        for tag in sorted(task_run.tags)
    ]
    if get_stream_subtask_execution() is not None:
        # Ordinary EventsWorker supplies this relation from the Flow context.
        # Physical Tasks intentionally have no such context or worker transport.
        related.append(
            {
                "prefect.resource.id": f"prefect.flow-run.{task_run.flow_run_id}",
                "prefect.resource.role": "flow-run",
            }
        )
    return Event.model_validate(
        {
            "id": validated_state.id,
            "occurred": validated_state.timestamp,
            "event": f"prefect.task-run.{validated_state.name}",
            "payload": payload,
            "resource": resource,
            "related": related,
            "follows": (
                follows.id
                if follows is not None
                and abs(validated_state.timestamp - follows.occurred)
                < timedelta(minutes=5)
                else None
            ),
        }
    )


def emit_task_run_state_change_event(
    task_run: TaskRun,
    initial_state: Optional[State[Any]],
    validated_state: State[Any],
    follows: Optional[Event] = None,
) -> Optional[Event]:
    event = build_task_run_state_change_event(
        task_run, initial_state, validated_state, follows
    )
    return emit_event(
        id=event.id,
        occurred=event.occurred,
        event=event.event,
        payload=event.payload,
        resource=dict(event.resource),
        related=[dict(resource) for resource in event.related],
        follows=follows,
    )


def _dag_event_stopped(message: str) -> NoReturn:
    # The entrypoint composes TaskEngine; defer its signal import until Task
    # initialization is complete, retaining the existing signal class identity.
    from prefect._internal.stream_subtask_entrypoint import (
        PhysicalStreamExecutionStopped,
    )

    raise PhysicalStreamExecutionStopped(message)


def _freeze_dag_task_event(event: Event) -> bytes:
    execution = get_stream_subtask_execution()
    if not isinstance(execution, DAGSubtaskExecutionContext):
        _dag_event_stopped("DAG TaskRun event requires its own scoped grant")
    try:
        frozen = json.dumps(
            event.model_dump(mode="json"),
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
        snapshot = Event.model_validate_json(frozen)
        if snapshot.resource[
            "prefect.resource.id"
        ] != f"prefect.task-run.{execution.task_run_id}" or snapshot.payload[
            "task_run"
        ]["id"] != str(execution.task_run_id):
            _dag_event_stopped("DAG event refers to another TaskRun")
    except Exception:
        _dag_event_stopped("DAG TaskRun event could not be frozen")
    return frozen


def _validate_dag_task_event_ack(snapshot: Event, result: Any) -> None:
    execution = get_stream_subtask_execution()
    if (
        not isinstance(execution, DAGSubtaskExecutionContext)
        or not result.accepted
        or result.event_id != snapshot.id
        or result.task_run_id != execution.task_run_id
        or result.run_count != snapshot.payload["task_run"]["run_count"]
        or result.state_type.value != snapshot.payload["validated_state"]["type"]
    ):
        _dag_event_stopped("DAG TaskRun event was fenced or its receipt differs")


def emit_dag_task_event(
    client: "SyncPrefectClient", event: Event, *, timeout: float = 20.0
) -> Event:
    """Send the same signed event across ACK loss; never GET a TaskRun.

    Unresolved acknowledgement fences this child. Its worker/server reconciles
    the durable state after exact exit, without inventing another Failed event.
    """
    frozen = _freeze_dag_task_event(event)
    snapshot = Event.model_validate_json(frozen)
    deadline = time.monotonic() + timeout
    while True:
        execution = get_stream_subtask_execution()
        if not isinstance(execution, DAGSubtaskExecutionContext):
            _dag_event_stopped("DAG TaskRun event lost its scoped grant")
        try:
            result = client.emit_stream_subtask_event(
                subtask_id=execution.subtask_id, event=json.loads(frozen)
            )
            _validate_dag_task_event_ack(snapshot, result)
            return snapshot
        except httpx.TransportError:
            if time.monotonic() >= deadline:
                _dag_event_stopped("DAG event acknowledgement remains unknown")
        except BaseException:
            _dag_event_stopped("DAG event transport refused its current grant")
        time.sleep(0.05)


async def aemit_dag_task_event(
    client: "PrefectClient", event: Event, *, timeout: float = 20.0
) -> Event:
    """Async counterpart with identical bytes, ownership and failure boundary."""
    frozen = _freeze_dag_task_event(event)
    snapshot = Event.model_validate_json(frozen)
    deadline = time.monotonic() + timeout
    while True:
        execution = get_stream_subtask_execution()
        if not isinstance(execution, DAGSubtaskExecutionContext):
            _dag_event_stopped("DAG TaskRun event lost its scoped grant")
        try:
            result = await client.emit_stream_subtask_event(
                subtask_id=execution.subtask_id, event=json.loads(frozen)
            )
            _validate_dag_task_event_ack(snapshot, result)
            return snapshot
        except httpx.TransportError:
            if time.monotonic() >= deadline:
                _dag_event_stopped("DAG event acknowledgement remains unknown")
        except BaseException:
            _dag_event_stopped("DAG event transport refused its current grant")
        await anyio.sleep(0.05)


def resolve_to_final_result(expr: Any, context: dict[str, Any]) -> Any:
    """
    Resolve any `PrefectFuture`, or `State` types nested in parameters into
    data. Designed to be use with `visit_collection`.
    """
    state: Optional[State[Any]] = None

    if isinstance(expr, _STREAM_GRAPH_METADATA_TYPES):
        refuse_stream_graph_dependencies(expr)

    # Expressions inside quotes should not be modified
    if isinstance(context.get("annotation"), quote):
        raise StopVisiting()

    _raise_on_run_schema_unless_opaque(expr, context)

    if isinstance(expr, StreamCollection):
        return run_coro_as_sync(expr.resolve())
    if isinstance(expr, Stream):
        if not context.get("allow_stream"):
            raise StreamProtocolError(
                "A finite dependency requires stream.collect(limit=...), not a bare Stream"
            )
        return expr

    if isinstance(expr, PrefectFuture):
        upstream_task_run: Optional[TaskRun] = context.get("current_task_run")
        upstream_task: Optional["Task[..., Any]"] = context.get("current_task")
        if (
            upstream_task
            and upstream_task_run
            and expr.task_run_id == upstream_task_run.id
        ):
            raise ValueError(
                f"Discovered a task depending on itself. Raising to avoid a deadlock. Please inspect the inputs and dependencies of {upstream_task.name}."
            )

        expr.wait()
        state = expr.state
    elif isinstance(expr, State):
        state = expr
    else:
        return expr

    assert state

    # Do not allow uncompleted upstreams unless `allow_failure` has been used
    # for failed or failure-derived (PENDING/NotReady) states
    if not state.is_completed() and not (
        # TODO: Note that the contextual annotation here is only at the current level
        #       if `allow_failure` is used then another annotation is used, this will
        #       incorrectly evaluate to false — to resolve this, we must track all
        #       annotations wrapping the current expression but this is not yet
        #       implemented.
        isinstance(context.get("annotation"), allow_failure)
        and (state.is_failed() or (state.is_pending() and state.name == "NotReady"))
    ):
        raise UpstreamTaskError(
            f"Upstream task run '{state.state_details.task_run_id}' did not reach a"
            " 'COMPLETED' state."
        )

    # When allow_failure is used and the state is not final (e.g. PENDING/NotReady
    # from a cascading upstream failure), we cannot call state.result() because it
    # raises UnfinishedRun.  Return the state's data directly instead.
    if not state.is_final() and isinstance(context.get("annotation"), allow_failure):
        return state.data

    result: Any = state.result(raise_on_failure=False, _sync=True)  # pyright: ignore[reportCallIssue] _sync messes up type inference and can be removed once async_dispatch is removed

    refuse_stream_graph_dependencies(result)

    if isinstance(result, (Stream, StreamCollection)):
        return resolve_to_final_result(result, context)

    # Check the resolved result: if a task returned a FlowRun/TaskRun, the
    # caller (visit_collection) would recurse into its Pydantic fields and
    # misinterpret the embedded .state as an upstream dependency.
    _raise_on_run_schema_unless_opaque(result, context)

    if state.state_details.traceparent:
        parameter_context = propagate.extract(
            {"traceparent": state.state_details.traceparent}
        )
        attributes = {}

        # If this future is being used as a parameter (as opposed to just a wait_for),
        # add attributes to the span to indicate the parameter name and type
        if "parameter_name" in context:
            attributes = {
                "prefect.input.name": context["parameter_name"],
                "prefect.input.type": type(result).__name__,
            }

        trace.get_current_span().add_link(
            context=trace.get_current_span(parameter_context).get_span_context(),
            attributes=attributes,
        )

    return result


def resolve_inputs_sync(
    parameters: dict[str, Any], return_data: bool = True, max_depth: int = -1
) -> dict[str, Any]:
    """
    Resolve any `Quote`, `PrefectFuture`, or `State` types nested in parameters into
    data.

    Returns:
        A copy of the parameters with resolved data

    Raises:
        UpstreamTaskError: If any of the upstream states are not `COMPLETED`
    """

    if not parameters:
        return {}

    resolved_parameters: dict[str, Any] = {}
    for parameter, value in parameters.items():
        try:
            resolved_parameters[parameter] = visit_collection(
                value,
                visit_fn=resolve_to_final_result,
                return_data=return_data,
                max_depth=max_depth,
                remove_annotations=True,
                context={"parameter_name": parameter},
            )
        except (UpstreamTaskError, PrefectException):
            raise
        except Exception as exc:
            raise PrefectException(
                f"Failed to resolve inputs in parameter {parameter!r}. If your"
                " parameter type is not supported, consider using the `quote`"
                " annotation to skip resolution of inputs, or the `opaque`"
                " annotation to resolve the value without traversing its contents."
            ) from exc

    return resolved_parameters
