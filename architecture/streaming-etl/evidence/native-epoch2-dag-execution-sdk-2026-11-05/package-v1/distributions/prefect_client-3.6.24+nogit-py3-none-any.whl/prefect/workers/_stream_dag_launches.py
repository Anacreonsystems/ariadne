"""Secret-free local launch fences; the server owns the complete attempt set.

A local intent is durable before PREPARE and a birth fence before Popen. A
reserved birth without an exact recorded PID is unknown, never unstarted.
This journal does not manufacture kernel death evidence or free server slots.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import tempfile
import threading
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, cast
from uuid import UUID

from prefect._internal.stream_dag_subtask_protocol import (
    DAG_MAX_LAUNCH_ATTEMPTS,
    dag_launch_prepare_operation_id,
)
from prefect._internal.stream_route_plan import canonical_route_json

_SCHEMA = "prefect-dag-local-launch-v1"
_MAX_RECORD_BYTES = 16 * 1024
_DIGEST = re.compile(r"[0-9a-f]{64}")


class DAGLaunchJournalError(ValueError):
    """Local launch ownership cannot be proved; retain the physical slot."""


def _uuid(value: UUID) -> None:
    if type(value) is not UUID:
        raise DAGLaunchJournalError("Local launch identities must be exact UUIDs")


def _positive(value: int, maximum: int | None = None) -> None:
    if type(value) is not int or value < 1 or maximum is not None and value > maximum:
        raise DAGLaunchJournalError("Local launch coordinates must be exact integers")


@dataclass(frozen=True)
class DAGLocalLaunch:
    operation_id: UUID
    start_operation_id: UUID
    replacement_operation_id: UUID | None = None
    launch_attempt_id: UUID | None = None
    attempt_index: int | None = None
    birth_reserved: bool = False
    child_process_id: int | None = None
    process_start_ticks: int | None = None
    spawn_fence_closed: bool = False

    def __post_init__(self) -> None:
        if type(self) is not DAGLocalLaunch:
            raise DAGLaunchJournalError("Local launch records cannot be extended")
        for value in (self.operation_id, self.start_operation_id):
            _uuid(value)
        for optional in (self.replacement_operation_id, self.launch_attempt_id):
            if optional is not None:
                _uuid(optional)
        if self.attempt_index is not None:
            _positive(self.attempt_index, DAG_MAX_LAUNCH_ATTEMPTS)
        if (self.launch_attempt_id is None) != (self.attempt_index is None):
            raise DAGLaunchJournalError("A launch binding requires its exact index")
        if (
            type(self.birth_reserved) is not bool
            or type(self.spawn_fence_closed) is not bool
        ):
            raise DAGLaunchJournalError("Local launch fences must be exact booleans")
        if (self.child_process_id is None) != (self.process_start_ticks is None):
            raise DAGLaunchJournalError("A recorded child requires PID and start ticks")
        if self.child_process_id is not None:
            _positive(self.child_process_id)
            assert self.process_start_ticks is not None
            _positive(self.process_start_ticks)
            if not self.birth_reserved:
                raise DAGLaunchJournalError("A child cannot precede its birth fence")
        if self.birth_reserved and self.launch_attempt_id is None:
            raise DAGLaunchJournalError("A birth requires a server-issued attempt")
        if (
            self.spawn_fence_closed
            and self.birth_reserved
            and self.child_process_id is None
        ):
            raise DAGLaunchJournalError("An unknown birth cannot attest safe closure")


class DAGLaunchJournal:
    """One private, bounded journal for an assigned subtask/worker generation."""

    def __init__(
        self,
        directory: Path,
        *,
        worker_id: UUID,
        worker_generation_digest: str,
        graph_revision_id: UUID,
        subtask_id: UUID,
    ) -> None:
        for identity in (worker_id, graph_revision_id, subtask_id):
            _uuid(identity)
        if type(worker_generation_digest) is not str or not _DIGEST.fullmatch(
            worker_generation_digest
        ):
            raise DAGLaunchJournalError(
                "A canonical worker-generation digest is required"
            )
        self.directory = directory
        self.worker_id = worker_id
        self.worker_generation_digest = worker_generation_digest
        self.graph_revision_id = graph_revision_id
        self.subtask_id = subtask_id
        self._mutex = threading.RLock()
        self._broken = False
        self._recovered = False
        self._records: dict[UUID, DAGLocalLaunch] = {}
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        info = directory.lstat()
        if (
            not stat.S_ISDIR(info.st_mode)
            or info.st_uid != os.getuid()
            or info.st_mode & 0o077
        ):
            raise DAGLaunchJournalError(
                "A launch journal requires a private owned directory"
            )
        self._load()

    def _document(self, record: DAGLocalLaunch) -> dict[str, object]:
        values = asdict(record)
        for name in (
            "operation_id",
            "start_operation_id",
            "replacement_operation_id",
            "launch_attempt_id",
        ):
            if values[name] is not None:
                values[name] = str(values[name])
        return {
            "schema": _SCHEMA,
            "worker_id": str(self.worker_id),
            "worker_generation_digest": self.worker_generation_digest,
            "graph_revision_id": str(self.graph_revision_id),
            "subtask_id": str(self.subtask_id),
            "record": values,
        }

    def digest(self, record: DAGLocalLaunch) -> str:
        if type(record) is not DAGLocalLaunch:
            raise DAGLaunchJournalError("An exact local launch record is required")
        return hashlib.sha256(
            b"prefect-dag-local-launch-journal-v1\0"
            + canonical_route_json(self._document(record))
        ).hexdigest()

    def _load(self) -> None:
        try:
            entries = tuple(self.directory.iterdir())
            if len(entries) > DAG_MAX_LAUNCH_ATTEMPTS or any(
                p.suffix != ".json" for p in entries
            ):
                raise DAGLaunchJournalError(
                    "A launch journal is oversized or has an unknown write"
                )
            for path in entries:
                descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                with os.fdopen(descriptor, "rb") as stream:
                    info = os.fstat(stream.fileno())
                    if (
                        not stat.S_ISREG(info.st_mode)
                        or info.st_uid != os.getuid()
                        or stat.S_IMODE(info.st_mode) != 0o600
                        or info.st_nlink != 1
                    ):
                        raise DAGLaunchJournalError(
                            "Local launch proof has unsafe ownership"
                        )
                    raw = stream.read(_MAX_RECORD_BYTES + 1)
                if not raw or len(raw) > _MAX_RECORD_BYTES:
                    raise DAGLaunchJournalError(
                        "Local launch proof is absent or oversized"
                    )
                parsed_value: object = json.loads(raw)
                value = cast(dict[str, Any], parsed_value)
                if raw != canonical_route_json(value):
                    raise DAGLaunchJournalError(
                        "Local launch proof is not canonical JSON"
                    )
                if type(parsed_value) is not dict or set(value) != {
                    "schema",
                    "worker_id",
                    "worker_generation_digest",
                    "graph_revision_id",
                    "subtask_id",
                    "record",
                    "checksum",
                }:
                    raise DAGLaunchJournalError("Local launch proof has another shape")
                raw_payload = value["record"]
                payload = cast(dict[str, Any], raw_payload)
                if type(raw_payload) is not dict or set(payload) != set(
                    DAGLocalLaunch.__dataclass_fields__
                ):
                    raise DAGLaunchJournalError("Local launch record has another shape")
                payload = payload.copy()
                for name in (
                    "operation_id",
                    "start_operation_id",
                    "replacement_operation_id",
                    "launch_attempt_id",
                ):
                    if payload[name] is not None:
                        if type(payload[name]) is not str:
                            raise DAGLaunchJournalError(
                                "Local launch identity is not canonical"
                            )
                        parsed = UUID(payload[name])
                        if str(parsed) != payload[name]:
                            raise DAGLaunchJournalError(
                                "Local launch identity is not canonical"
                            )
                        payload[name] = parsed
                record = DAGLocalLaunch(**payload)
                if (
                    value != {**self._document(record), "checksum": self.digest(record)}
                    or path.name != str(record.operation_id) + ".json"
                ):
                    raise DAGLaunchJournalError(
                        "Local launch proof belongs to another assignment"
                    )
                expected = dag_launch_prepare_operation_id(
                    self.subtask_id,
                    record.start_operation_id,
                    record.replacement_operation_id,
                )
                if record.operation_id != expected:
                    raise DAGLaunchJournalError(
                        "Local launch operation has another authorization"
                    )
                self._records[record.operation_id] = record
        except (OSError, ValueError, TypeError) as error:
            self._broken = True
            raise DAGLaunchJournalError(
                "Local launch recovery requires retained capacity"
            ) from error

    def _check(self) -> None:
        if self._broken or not self._recovered:
            raise DAGLaunchJournalError("Local launch recovery is not complete")

    def reconcile(self, expected: dict[UUID, tuple[UUID, int]]) -> None:
        """Check the complete server view; an absent local intent is unknown."""
        with self._mutex:
            if (
                self._broken
                or type(expected) is not dict
                or len(expected) > DAG_MAX_LAUNCH_ATTEMPTS
            ):
                raise DAGLaunchJournalError(
                    "The complete server attempt view is required"
                )
            self._recovered = False
            seen_ids: set[UUID] = set()
            seen_indices: set[int] = set()
            for operation_id, binding in expected.items():
                _uuid(operation_id)
                if type(binding) is not tuple or len(binding) != 2:
                    raise DAGLaunchJournalError(
                        "The server launch binding is not exact"
                    )
                attempt_id, index = binding
                _uuid(attempt_id)
                _positive(index, DAG_MAX_LAUNCH_ATTEMPTS)
                if attempt_id in seen_ids or index in seen_indices:
                    raise DAGLaunchJournalError(
                        "The server launch identities are aliased"
                    )
                seen_ids.add(attempt_id)
                seen_indices.add(index)
                local = self._records.get(operation_id)
                if (
                    local is None
                    or local.launch_attempt_id not in (None, attempt_id)
                    or local.attempt_index not in (None, index)
                ):
                    raise DAGLaunchJournalError(
                        "A server attempt has no matching local proof"
                    )
            if any(
                record.launch_attempt_id is not None and operation_id not in expected
                for operation_id, record in self._records.items()
            ):
                raise DAGLaunchJournalError(
                    "The server attempt view omitted a bound local launch"
                )
            self._recovered = True

    @contextmanager
    def spawn_stop_mutex(self) -> Generator[None, None, None]:
        with self._mutex:
            self._check()
            yield

    def intent(
        self, start_operation_id: UUID, replacement_operation_id: UUID | None = None
    ) -> DAGLocalLaunch:
        with self._mutex:
            self._check()
            _uuid(start_operation_id)
            if replacement_operation_id is not None:
                _uuid(replacement_operation_id)
            operation_id = dag_launch_prepare_operation_id(
                self.subtask_id, start_operation_id, replacement_operation_id
            )
            existing = self._records.get(operation_id)
            if existing is not None:
                if (existing.start_operation_id, existing.replacement_operation_id) != (
                    start_operation_id,
                    replacement_operation_id,
                ):
                    raise DAGLaunchJournalError(
                        "A launch intent cannot change its authorization"
                    )
                return existing
            if len(self._records) >= DAG_MAX_LAUNCH_ATTEMPTS:
                raise DAGLaunchJournalError(
                    "The local launch attempt bound is exhausted"
                )
            return self._persist(
                DAGLocalLaunch(
                    operation_id, start_operation_id, replacement_operation_id
                )
            )

    def bind(
        self, operation_id: UUID, launch_attempt_id: UUID, attempt_index: int
    ) -> DAGLocalLaunch:
        with self._mutex:
            _uuid(launch_attempt_id)
            _positive(attempt_index, DAG_MAX_LAUNCH_ATTEMPTS)
            record = self.read(operation_id)
            if record.launch_attempt_id is not None:
                if (record.launch_attempt_id, record.attempt_index) != (
                    launch_attempt_id,
                    attempt_index,
                ):
                    raise DAGLaunchJournalError(
                        "A local intent cannot change its server binding"
                    )
                return record
            # A delayed PREPARE acknowledgement can still attach its server ID
            # to a closed, unstarted intent. The closed birth fence stays closed.
            return self._persist(
                replace(
                    record,
                    launch_attempt_id=launch_attempt_id,
                    attempt_index=attempt_index,
                )
            )

    def reserve_birth(self, operation_id: UUID) -> DAGLocalLaunch:
        with self._mutex:
            record = self.read(operation_id)
            if record.spawn_fence_closed or record.birth_reserved:
                raise DAGLaunchJournalError(
                    "This launch cannot acquire a second process birth"
                )
            return self._persist(replace(record, birth_reserved=True))

    def record_process(
        self, operation_id: UUID, pid: int, start_ticks: int
    ) -> DAGLocalLaunch:
        with self._mutex:
            _positive(pid)
            _positive(start_ticks)
            record = self.read(operation_id)
            if record.spawn_fence_closed or not record.birth_reserved:
                raise DAGLaunchJournalError(
                    "A recorded process requires its open birth fence"
                )
            if record.child_process_id is not None:
                if (record.child_process_id, record.process_start_ticks) != (
                    pid,
                    start_ticks,
                ):
                    raise DAGLaunchJournalError(
                        "A launch attempt cannot record a second PID"
                    )
                return record
            return self._persist(
                replace(record, child_process_id=pid, process_start_ticks=start_ticks)
            )

    def close_unstarted(self, operation_id: UUID) -> DAGLocalLaunch:
        with self._mutex:
            record = self.read(operation_id)
            if record.birth_reserved:
                raise DAGLaunchJournalError(
                    "A reserved birth cannot attest CLOSED_UNSTARTED"
                )
            return (
                record
                if record.spawn_fence_closed
                else self._persist(replace(record, spawn_fence_closed=True))
            )

    def close_after_verified_death(
        self, operation_id: UUID, pid: int, start_ticks: int
    ) -> DAGLocalLaunch:
        """Fence locally after the caller has retained exact kernel death proof."""
        with self._mutex:
            _positive(pid)
            _positive(start_ticks)
            record = self.read(operation_id)
            if record.child_process_id is None or (
                record.child_process_id,
                record.process_start_ticks,
            ) != (pid, start_ticks):
                raise DAGLaunchJournalError(
                    "A death proof must match the recorded local process"
                )
            return (
                record
                if record.spawn_fence_closed
                else self._persist(replace(record, spawn_fence_closed=True))
            )

    def process_record_digest(self, operation_id: UUID) -> str:
        """Keep RECORD replay material stable after the local stop fence closes."""
        record = self.read(operation_id)
        if record.child_process_id is None:
            raise DAGLaunchJournalError("RECORD requires a journaled process identity")
        return self.digest(replace(record, spawn_fence_closed=False))

    def read(self, operation_id: UUID) -> DAGLocalLaunch:
        self._check()
        _uuid(operation_id)
        try:
            return self._records[operation_id]
        except KeyError as error:
            raise DAGLaunchJournalError("The local launch intent is unknown") from error

    def _persist(self, record: DAGLocalLaunch) -> DAGLocalLaunch:
        encoded = canonical_route_json(
            {**self._document(record), "checksum": self.digest(record)}
        )
        if len(encoded) > _MAX_RECORD_BYTES:
            raise DAGLaunchJournalError("The local launch record is oversized")
        descriptor = -1
        directory_fd = -1
        temporary: str | None = None
        try:
            descriptor, temporary = tempfile.mkstemp(
                prefix=".pending-", dir=self.directory
            )
            with os.fdopen(descriptor, "wb") as stream:
                descriptor = -1
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.directory / (str(record.operation_id) + ".json"))
            temporary = None
            directory_fd = os.open(
                self.directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
            )
            os.fsync(directory_fd)
        except OSError as error:
            self._broken = True
            raise DAGLaunchJournalError(
                "A local durability acknowledgement is unknown"
            ) from error
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            if directory_fd >= 0:
                os.close(directory_fd)
            # Retain an interrupted write as evidence. Recovery then refuses it;
            # deleting it could erase an unknown transition across a crash cut.
        self._records[record.operation_id] = record
        return record
