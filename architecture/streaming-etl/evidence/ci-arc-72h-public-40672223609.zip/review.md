# Long-soak review: LONG SOAK PASS

- Run: `gh-40672223609-1`
- Measured elapsed: `259298.2` seconds
- Segments: `18`
- Source records: `188659`
- Owner faults: `1867`
- Process boots: `3`
- `long_soak_passed`: `true`
- `smoke_passed`: `false`
- Resource policy: `long_absolute_and_rate_caps`

## Violations

- None

## Scope

- real PostgreSQL 17 synchronous remote_apply pair
- ordinary Python yield DAG source->A->{B,C}->J->D
- periodic barriers and bounded retirement/GC
- release-session storage guard
- owner loss and externally scheduled service-process loss
- actual Prefect integration remains separate short R4-B evidence
