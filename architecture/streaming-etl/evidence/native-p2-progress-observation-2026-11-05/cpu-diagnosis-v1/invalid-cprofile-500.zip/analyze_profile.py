import hashlib
import json
from pathlib import Path
import pstats
import subprocess

ROOT=Path('/tmp/native-server-cprofile-500-v1')
SOURCE=Path('/tmp/ariadne-native-5000-diagnosis-v1')
targets=json.loads((ROOT/'targets.json').read_text())
rows=[]
for target in targets:
 path=Path(target['profile'])
 stats=pstats.Stats(str(path))
 for (filename,line,function),(primitive,calls,self_time,cumulative,callers) in stats.stats.items():
  row={'file':filename,'line':line,'function':function,'primitive_calls':primitive,'calls':calls,
       'self_cpu_seconds':self_time,'cumulative_cpu_seconds':cumulative,
       'top_callers':[{'file':key[0],'line':key[1],'function':key[2],'metrics':value}
                      for key,value in sorted(callers.items(),key=lambda item:item[1][-1] if isinstance(item[1],tuple) else item[1],reverse=True)[:8]]}
  if filename.startswith(str(SOURCE)+'/src/'):
   file=Path(filename);relative=file.relative_to(SOURCE).as_posix()
   check=subprocess.run(['git','show','8ad97915c8908c5175d6e6efbe47ee747704d868:'+relative],cwd=SOURCE,capture_output=True)
   baseline=check.stdout if check.returncode==0 else None
   row.update(source_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),
              eight_ad_sha256=hashlib.sha256(baseline).hexdigest() if baseline is not None else None,source_matches_8ad=file.read_bytes()==baseline if baseline is not None else None)
   lines=file.read_text().splitlines();row['source_excerpt']='\n'.join(f'{i+1}: {lines[i]}' for i in range(max(0,line-1),min(len(lines),line+16)))
  rows.append(row)
 metadata=json.loads(path.with_suffix('.metadata.json').read_text())
 results={'profile':str(path),'metadata':metadata,'profile_total_calls':stats.total_calls,
          'profile_primitive_calls':stats.prim_calls,'profile_total_self_cpu_seconds':stats.total_tt,
          'top_self':sorted(rows,key=lambda row:row['self_cpu_seconds'],reverse=True)[:50],
          'top_cumulative':sorted(rows,key=lambda row:row['cumulative_cpu_seconds'],reverse=True)[:50],
          'top_own_source_self':sorted((r for r in rows if 'source_sha256' in r),key=lambda row:row['self_cpu_seconds'],reverse=True)[:35],
          'top_own_source_cumulative':sorted((r for r in rows if 'source_sha256' in r),key=lambda row:row['cumulative_cpu_seconds'],reverse=True)[:35]}
 (ROOT/'profile-analysis.json').write_text(json.dumps(results,indent=2)+'\n')
 for kind in ('top_self','top_own_source_self','top_own_source_cumulative'):
  print(kind)
  for row in results[kind][:12]:
   print(f"{row['self_cpu_seconds']:.3f}s self {row['cumulative_cpu_seconds']:.3f}s cum {row['calls']}calls {row['file']}:{row['line']} {row['function']}")
 print(json.dumps({key:metadata[key] for key in ('wall_seconds','process_cpu_seconds','main_thread_cpu_seconds','foreign_prefect_imports')}))
