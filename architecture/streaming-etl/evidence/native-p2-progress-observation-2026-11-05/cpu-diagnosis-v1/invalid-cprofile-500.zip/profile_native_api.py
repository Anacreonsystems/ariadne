"""Run only the test-owned native API under standard main-thread CPU cProfile."""

import cProfile
import hashlib
import json
from pathlib import Path
import runpy
import signal
import sys
import time

target = Path(sys.argv[1])
source = Path(sys.argv[2]).resolve()
arguments = sys.argv[3:]
if arguments[:2] != ["-m", "uvicorn"]:
    raise SystemExit("Only the explicit uvicorn module may be profiled")


def stopped(number, frame):
    # Uvicorn restores this pre-existing handler after graceful application
    # shutdown, then re-raises the received signal. Unwind and flush, not kill.
    raise SystemExit(128 + number)


signal.signal(signal.SIGTERM, stopped)
signal.signal(signal.SIGINT, stopped)
started = (time.perf_counter(), time.process_time(), time.thread_time())
profile = cProfile.Profile(timer=time.thread_time)
sys.argv = ["uvicorn", *arguments[2:]]
try:
    profile.enable()
    runpy.run_module("uvicorn", run_name="__main__", alter_sys=True)
finally:
    profile.disable()
    profile.dump_stats(str(target))
    modules = {
        name: getattr(module, "__file__", None)
        for name, module in list(sys.modules.items())
        if name == "prefect" or name.startswith("prefect.")
    }
    foreign = {
        name: path
        for name, path in modules.items()
        if path and not Path(path).resolve().is_relative_to(source / "src" / "prefect")
    }
    metadata = {
        "timer": "time.thread_time",
        "wall_seconds": time.perf_counter() - started[0],
        "process_cpu_seconds": time.process_time() - started[1],
        "main_thread_cpu_seconds": time.thread_time() - started[2],
        "profile_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "prefect_import_files": modules,
        "foreign_prefect_imports": foreign,
        "qualification": "cProfile main-thread CPU only; instrumentation overhead present; no throughput comparison",
    }
    target.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, indent=2) + "\n"
    )
