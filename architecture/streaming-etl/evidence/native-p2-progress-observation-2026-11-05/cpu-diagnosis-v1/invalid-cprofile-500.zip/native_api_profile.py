"""Inject profiling only into RestartableAPI's exact native uvicorn command."""

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

DIRECTORY = Path(os.environ["NATIVE_API_PROFILE_DIRECTORY"]).resolve()
SOURCE = Path(os.environ["NATIVE_API_PROFILE_SOURCE"]).resolve()
ORIGINAL = subprocess.Popen
TARGETS = []


class ProfilePopen(ORIGINAL):
    def __init__(self, args, *positional, **kwargs):
        marker = None
        if (
            isinstance(args, (list, tuple))
            and len(args) > 3
            and list(args[1:3]) == ["-m", "uvicorn"]
        ):
            marker = next(
                (
                    value
                    for value in args
                    if isinstance(value, str)
                    and value.startswith("X-Native-Recovery-ID:")
                ),
                None,
            )
        if marker is not None:
            path = DIRECTORY / ("native-api-" + marker.partition(":")[2] + ".cprof")
            replacement = [
                sys.executable,
                str(DIRECTORY / "profile_native_api.py"),
                str(path),
                str(SOURCE),
                *args[1:],
            ]
            super().__init__(replacement, *positional, **kwargs)
            raw = Path("/proc") / str(self.pid) / "stat"
            value = raw.read_text()
            ticks = int(value[value.rfind(")") + 2 :].split()[19])
            TARGETS.append(
                {
                    "pid": self.pid,
                    "process_start_ticks": ticks,
                    "profile": str(path),
                    "original_argv": list(args),
                    "profiled_argv": replacement,
                }
            )
            (DIRECTORY / "targets.json").write_text(
                json.dumps(TARGETS, indent=2) + "\n"
            )
        else:
            super().__init__(args, *positional, **kwargs)


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    subprocess.Popen = ProfilePopen


@pytest.hookimpl(trylast=True)
def pytest_sessionfinish(session, exitstatus):
    subprocess.Popen = ORIGINAL
    (DIRECTORY / "session-receipt.json").write_text(
        json.dumps(
            {
                "exitstatus": exitstatus,
                "target_count": len(TARGETS),
                "profiles_flushed": [
                    Path(item["profile"]).exists() for item in TARGETS
                ],
            },
            indent=2,
        )
        + "\n"
    )
