"""Bounded POSIX process-CPU sampling of the test-owned native API."""

from collections import Counter
import json
from pathlib import Path
import runpy
import signal
import sys
import time

OUTPUT = Path(sys.argv[1])
SOURCE = Path(sys.argv[2]).resolve()
CASE = Path(sys.argv[3])
arguments = sys.argv[4:]
if arguments[:2] != ["-m", "uvicorn"]:
    raise SystemExit("Only uvicorn may be sampled")
START = (time.perf_counter(), time.process_time(), time.thread_time())
COUNTS = {
    phase: {
        "leaf": Counter(),
        "inclusive": Counter(),
        "line": Counter(),
        "stacks": Counter(),
        "samples": 0,
    }
    for phase in ("startup", "data")
}
DATA_START = None
HANDLING = False


def sample(number, frame):
    global DATA_START, HANDLING
    if HANDLING:
        return
    HANDLING = True
    try:
        if DATA_START is None and any(
            (CASE / f"source-first-accepted-{i}.time").exists() for i in (0, 1)
        ):
            DATA_START = (time.perf_counter(), time.process_time(), time.thread_time())
        bucket = COUNTS["data" if DATA_START is not None else "startup"]
        stack = []
        while frame is not None and len(stack) < 80:
            code = frame.f_code
            stack.append(
                (code.co_filename, code.co_firstlineno, code.co_name, frame.f_lineno)
            )
            frame = frame.f_back
        if stack:
            bucket["samples"] += 1
            bucket["leaf"][stack[0][:3]] += 1
            bucket["line"][stack[0]] += 1
            bucket["stacks"][tuple(stack)] += 1
            for function in {value[:3] for value in stack}:
                bucket["inclusive"][function] += 1
    finally:
        HANDLING = False


def stopped(number, frame):
    raise SystemExit(128 + number)


signal.signal(signal.SIGTERM, stopped)
signal.signal(signal.SIGINT, stopped)
signal.signal(signal.SIGPROF, sample)
signal.setitimer(signal.ITIMER_PROF, 0.01, 0.01)
sys.argv = ["uvicorn", *arguments[2:]]
try:
    runpy.run_module("uvicorn", run_name="__main__", alter_sys=True)
finally:
    signal.setitimer(signal.ITIMER_PROF, 0)
    ended = (time.perf_counter(), time.process_time(), time.thread_time())
    modules = {
        name: getattr(module, "__file__", None)
        for name, module in list(sys.modules.items())
        if name == "prefect" or name.startswith("prefect.")
    }
    result = {
        "method": "POSIX_ITIMER_PROF",
        "interval_seconds": 0.01,
        "case_directory": str(CASE),
        "wall_seconds": ended[0] - START[0],
        "process_cpu_seconds": ended[1] - START[1],
        "main_thread_cpu_seconds": ended[2] - START[2],
        "data_start_offsets": None
        if DATA_START is None
        else [value - START[i] for i, value in enumerate(DATA_START)],
        "data_phase_cpu_seconds": None
        if DATA_START is None
        else ended[1] - DATA_START[1],
        "data_phase_main_cpu_seconds": None
        if DATA_START is None
        else ended[2] - DATA_START[2],
        "prefect_import_files": modules,
        "foreign_prefect_imports": {
            name: path
            for name, path in modules.items()
            if path
            and not Path(path).resolve().is_relative_to(SOURCE / "src" / "prefect")
        },
        "qualification": "Statistical main-thread Python stacks sampled on process CPU ticks; C-extension cost appears at its Python caller. No exact per-function timing/throughput claim.",
        "phases": {},
    }
    for phase, bucket in COUNTS.items():
        result["phases"][phase] = {
            "samples": bucket["samples"],
            "leaf": [
                {"file": key[0], "line": key[1], "function": key[2], "samples": count}
                for key, count in bucket["leaf"].most_common()
            ],
            "inclusive": [
                {"file": key[0], "line": key[1], "function": key[2], "samples": count}
                for key, count in bucket["inclusive"].most_common()
            ],
            "current_lines": [
                {"file": key[0], "line": key[3], "function": key[2], "samples": count}
                for key, count in bucket["line"].most_common()
            ],
            "stacks": [
                {"frames": key, "samples": count}
                for key, count in bucket["stacks"].most_common()
            ],
        }
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
