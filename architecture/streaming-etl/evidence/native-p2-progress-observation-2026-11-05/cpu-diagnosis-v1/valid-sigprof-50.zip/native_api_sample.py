"""External diagnostic50 parametrization; existing test/source bytes unchanged."""

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

DIRECTORY = Path(os.environ["NATIVE_API_SAMPLE_DIRECTORY"]).resolve()
SOURCE = Path(os.environ["NATIVE_API_SAMPLE_SOURCE"]).resolve()
ORIGINAL = subprocess.Popen
TARGETS = []


class SamplePopen(ORIGINAL):
    def __init__(self, args, *positional, **kwargs):
        marker = None
        if (
            isinstance(args, (list, tuple))
            and len(args) > 3
            and list(args[1:3]) == ["-m", "uvicorn"]
        ):
            marker = next(
                (
                    value
                    for value in args
                    if isinstance(value, str)
                    and value.startswith("X-Native-Recovery-ID:")
                ),
                None,
            )
        if marker is not None:
            output = DIRECTORY / (
                "native-api-" + marker.partition(":")[2] + ".samples.json"
            )
            case = Path(kwargs["stdout"].name).parent
            replacement = [
                sys.executable,
                str(DIRECTORY / "sample_native_api.py"),
                str(output),
                str(SOURCE),
                str(case),
                *args[1:],
            ]
            super().__init__(replacement, *positional, **kwargs)
            value = (Path("/proc") / str(self.pid) / "stat").read_text()
            ticks = int(value[value.rfind(")") + 2 :].split()[19])
            TARGETS.append(
                {
                    "pid": self.pid,
                    "process_start_ticks": ticks,
                    "output": str(output),
                    "case_directory": str(case),
                    "original_argv": list(args),
                    "sampled_argv": replacement,
                }
            )
            (DIRECTORY / "targets.json").write_text(
                json.dumps(TARGETS, indent=2) + "\n"
            )
        else:
            super().__init__(args, *positional, **kwargs)


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    subprocess.Popen = SamplePopen


@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(items):
    assert len(items) == 1 and items[0].nodeid.endswith("[8-none-False]")
    item = items[0]
    assert item.callspec.params == {"count": 8, "fault": "none", "asynchronous": False}
    item.callspec.params["count"] = 50
    before = item.nodeid
    item._nodeid = item.nodeid.replace("[8-none-False]", "[diagnostic50-none-False]")
    (DIRECTORY / "selection.json").write_text(
        json.dumps(
            {
                "original_nodeid": before,
                "diagnostic_nodeid": item.nodeid,
                "params": item.callspec.params,
                "matrix_acceptance": False,
                "existing_assertions_unmodified": True,
            },
            indent=2,
        )
        + "\n"
    )


@pytest.hookimpl(trylast=True)
def pytest_sessionfinish(session, exitstatus):
    subprocess.Popen = ORIGINAL
    (DIRECTORY / "session-receipt.json").write_text(
        json.dumps(
            {
                "exitstatus": exitstatus,
                "target_count": len(TARGETS),
                "samples_flushed": [Path(item["output"]).exists() for item in TARGETS],
            },
            indent=2,
        )
        + "\n"
    )
